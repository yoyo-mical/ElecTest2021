@echo off
setlocal
cd /d "%~dp0"
if not exist "VendorSDK\CASDK2Net.dll" (
 echo Missing VendorSDK\CASDK2Net.dll - copy the original x86 vendor assembly here.
 pause
 exit /b 1
)
set "ELEC_MSBUILD="
for /f "usebackq delims=" %%I in (`"%ProgramFiles(x86)%\Microsoft Visual Studio\Installer\vswhere.exe" -latest -products * -requires Microsoft.Component.MSBuild -find MSBuild\**\Bin\MSBuild.exe`) do set "ELEC_MSBUILD=%%I"
if not defined ELEC_MSBUILD (
 echo Install Visual Studio or Build Tools with .NET desktop build tools and .NET Framework 4.8 targeting pack.
 pause
 exit /b 1
)
"%ELEC_MSBUILD%" "Testplan\ElecTest2026.csproj" /t:Rebuild /p:Configuration=Release "/p:VendorSdkDirectory=%~dp0VendorSDK" /fl "/flp:logfile=%~dp0build.log;verbosity=normal"
if errorlevel 1 (
 echo Build failed. See build.log. No successful test package has been produced.
 pause
 exit /b 1
)
if not exist "Testplan\bin\Release\CASDK2Net.dll" (
 echo Vendor assembly was not copied to output. Check build.log.
 pause
 exit /b 1
)
echo Built: Testplan\bin\Release\ElecTest2026.exe
echo Install the original vendor SDK and drivers, .NET Framework 4.8 and WebView2 Runtime before testing.
echo This is an unsigned local test build, not a protected release.
pause
