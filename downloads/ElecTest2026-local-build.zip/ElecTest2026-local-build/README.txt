ElecTest2026 本机补齐构建包（不是已编译可运行包）

1. 将原版 x86 CASDK2Net.dll 放到本包 VendorSDK 文件夹。
   工程历史引用版本 1.0.7332.25097；优先使用旧软件实际工作的版本。
   Admesy.dll 历史引用版本 1.1.0.0，当前源码未发现调用；有则一并放入。
2. Windows 安装 Visual Studio / Build Tools 的 .NET 桌面构建工具和 .NET Framework 4.8 开发/目标包。
3. 双击 BUILD.cmd。结果与错误见 build.log。
4. 构建成功后的程序：Testplan\bin\Release\ElecTest2026.exe。
5. 本机还要安装原厂 CA-SDK/仪器驱动、.NET Framework 4.8 运行时和 Microsoft Edge WebView2 Runtime。
   厂商原生 DLL、COM 注册及 VC++ 运行库具体要求以原厂安装程序为准。不要仅复制 DLL 到系统目录。
6. 授权名单可在启动页选择；默认位置是程序目录 licenses\ElecTest2026.license.json。
   本包不附真实授权名单，保留启动授权检查。

这是源码与构建依赖包。不能只放入 DLL 就直接运行，必须先构建。
构建不含临时 SDK 替身，不绕过授权，也不会自动安装驱动或连接设备。
本地构建未混淆、未进行发布者签名；只用于内部联调，正式交付另走受保护发布流程。
Web 目录有编译内置哈希校验，不要随意编辑正式界面文件。

依赖及位置：
VendorSDK\CASDK2Net.dll              编译输入，必需，x86
VendorSDK\Admesy.dll                旧工程引用，当前未发现源码使用
Testplan\bin\Release\CASDK2Net.dll  编译成功自动复制；与EXE同目录
Testplan\bin\Release\Web\          构建自动复制，不要删改
Testplan\bin\Release\WebView2Loader.dll  本包已带x86版本，构建自动复制
Microsoft.Web.WebView2.*.dll / DockPanelSuite DLL  本包已带，构建自动复制
.NET Framework 4.8 / WebView2 Runtime / 厂商驱动  安装到Windows，不放VendorSDK目录

优先在旧软件安装目录、原工程 bin\Debug 或 bin\Release、CA-SDK安装目录寻找厂商DLL。
如果旧软件仍可测量，尽量在同一台电脑测试新版，以复用已正确安装的驱动环境。
