'use strict';
// Native-only UI adaptation. No preview data generators or simulated operations are shipped.
(() => {
 const uart=$('#uart>.body'),log=$('#serial-log'),heading=log.previousElementSibling,receive=document.createElement('section');receive.className='serial-receive';heading.before(receive);receive.append(heading);
 const toolbar=document.createElement('div');toolbar.className='serial-receive-toolbar';toolbar.innerHTML='<div class="serial-view-modes" role="group" aria-label="接收显示格式"><button id="rx-hex" aria-pressed="false">HEX</button><button id="rx-ascii" aria-pressed="true">ASCII</button></div><span class="spacer"></span><button id="rx-copy">复制</button>';toolbar.append($('[data-action=clear-log]'));receive.append(toolbar,log);
 const stats=document.createElement('p');stats.id='rx-stats';stats.className='serial-console-info';receive.append(stats,$('#serial-ascii'));
 const send=document.createElement('section');send.className='serial-manual-send';receive.after(send);send.innerHTML='<p class="section-label">SEND / 手动发送</p>';
 const modes=uart.querySelector('.radio-row'),row=uart.querySelector('.send-row');send.append(modes,row);modes.querySelector('input[value="字符串"]').parentElement.lastChild.textContent='文本（ASCII）';modes.querySelector('input[value=HEX]').checked=true;
 const ending=document.createElement('label');ending.className='serial-ending';ending.innerHTML='<span>文本结尾</span><select id="send-ending"><option value="none">不追加</option><option value="cr">CR · 回车</option><option value="lf">LF · 换行</option><option value="crlf">CRLF · 回车换行</option></select>';send.append(ending);
 const sendStatus=document.createElement('p');sendStatus.id='serial-send-status';sendStatus.className='serial-console-info';sendStatus.textContent='发送格式独立于接收显示；HEX 不追加结尾。';send.append(sendStatus);
 let rxMode='ASCII',lastRx=null;
 function sendMode(){return modes.querySelector('input:checked').value==='HEX'?'HEX':'ASCII';}
 for(const radio of modes.querySelectorAll('input'))radio.onchange=()=>{ending.querySelector('select').disabled=!!state?.busy||sendMode()==='HEX';};
 row.querySelector('button').onclick=safe(async()=>{const fields={'serial.send':$('#send-data').value,'serial.sendMode':sendMode(),'serial.ending':$('#send-ending').value};const reply=await native('serial.send',{fields});applyState(reply.state);sendStatus.textContent='串口写入已完成（'+sendMode()+'）。';});
 let copyText='';
 function renderRx(){const raw=state?.serialRxHex||'';const key=rxMode+'|'+raw+'|'+state?.serialRxDropped;if(key===lastRx)return;lastRx=key;const bytes=raw?raw.split(/\s+/).filter(Boolean).map(x=>parseInt(x,16)):[];copyText=rxMode==='HEX'?raw:bytes.map(v=>v===9||v===10||v===13||v>=32&&v<=126?String.fromCharCode(v):'\\x'+v.toString(16).toUpperCase().padStart(2,'0')).join('');log.textContent=copyText||'等待串口数据…';requestAnimationFrame(()=>{log.scrollTop=log.scrollHeight;});log.dataset.format=rxMode;stats.textContent='接收 '+(state?.serialRxTotal||0)+' 字节 · '+rxMode+' 显示'+(state?.serialRxDropped?' · 查看区仅保留最近 64 KiB':'');for(const mode of ['HEX','ASCII'])$('#rx-'+mode.toLowerCase()).setAttribute('aria-pressed',String(rxMode===mode));$('#rx-copy').disabled=!bytes.length;}
 $('#rx-hex').onclick=()=>{rxMode='HEX';renderRx();};$('#rx-ascii').onclick=()=>{rxMode='ASCII';renderRx();};$('#rx-copy').onclick=safe(()=>native('clipboard.copy',{text:copyText}));
 $('#ascii-from-log').onclick=()=>{$('#ascii-source').value=state?.serialRxHex||'';$('#ascii-source').dispatchEvent(new Event('input',{bubbles:true}));};
 // Keep operations in their owning panels.
 const recipe=$('#recipe'),bar=$('.commandbar'),edit=recipe.querySelector('.recipe-toolbar'),run=document.createElement('div');run.className='recipe-run-controls';
 const head=$('#run-head'),current=$('#run-current'),pause=bar.querySelector('[data-action=pause]'),stepButton=bar.querySelector('[data-action=step]'),summary=bar.querySelector('.summary');head.classList.remove('primary');head.dataset.action='run';pause.lastChild.textContent='暂停';pause.title='在当前指令或采样步骤完成后的安全边界暂停';
 const resume=document.createElement('button');resume.id='native-resume';resume.textContent='继续';resume.onclick=safe(()=>command('resume'));
 const stop=document.createElement('button');stop.id='native-stop';stop.textContent='停止';stop.onclick=safe(()=>command('stop'));
 pause.id='recipe-pause-toggle';resume.hidden=true;run.append(head,current,pause,stop,stepButton);const area=document.createElement('div');area.className='recipe-command-area';edit.before(area);area.append(edit,run);edit.classList.add('recipe-edit-toolbar');recipe.querySelector('.panel-actions').prepend(summary);bar.remove();
 edit.querySelector('[data-action=import]').lastChild.textContent='导入配方';edit.querySelector('[data-action=export-recipe]').lastChild.textContent='导出配方';
 $('#code [data-action=download]').lastChild.textContent='Run Code';const target=document.createElement('span');target.id='arm-send-target';$('#code .code-footer').insertBefore(target,$('#line-count'));
 const exit=document.createElement('button');exit.id='app-exit';exit.textContent='退出';exit.onclick=safe(()=>native('exit'));$('.top-right').append(exit);
 function render(){
  renderRx();
  const busy=!!state?.busy,authorized=!!state?.authorized;
  for(const button of $$('[data-action],#run-head,#run-current,#recipe-format,#choose-control-file,#bold-recipe,#italic-recipe,.pattern-card'))button.disabled=!authorized||busy&&!['pause','reset','goto'].includes(button.dataset.action);
  pause.disabled=!state?.runningRecipe;pause.dataset.action=state?.pauseRequested?'resume':'pause';pause.lastChild.textContent=state?.pauseRequested?'继续':'暂停';pause.onclick=safe(()=>command(state?.pauseRequested?'resume':'pause'));stop.disabled=!busy;

  for(const input of $$('input[name=encoding],input[name=mode]'))input.disabled=busy;
  $('#send-ending').disabled=busy||sendMode()==='HEX';
  for(const [id,key]of [['apply-rgb','red'],['apply-gray','gray'],['apply-back','back']])$('#'+id).disabled=!authorized||busy||state?.enabled?.['pattern.'+key]===false;
  $('#ca-connect').classList.toggle('is-connected',!!state?.meterConnected);$('#ca-connect').setAttribute('aria-pressed',String(!!state?.meterConnected));
  target.textContent=state?.serialConnected?'目标：'+state.fields['serial.port']:'目标：串口未连接';

 }
 addEventListener('native-state',render);render();
})();
