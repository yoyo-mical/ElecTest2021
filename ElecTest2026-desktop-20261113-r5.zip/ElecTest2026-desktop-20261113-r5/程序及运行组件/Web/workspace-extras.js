'use strict';
// Shared layout tools use real native state and fixed C# operations, never demo producers.
(() => {
 const rgb=document.createElement('div');rgb.className='pattern-color-groups';
 function group(label,names,buttonId,cls){const fs=document.createElement('fieldset');fs.className='pattern-value-group';const title=document.createElement('legend');title.textContent=label;fs.append(title);const row=document.createElement('div');row.className=cls;for(const name of names)row.append(document.getElementById(name).closest('.field'));const button=document.getElementById(buttonId);button.textContent='应用';row.append(button);fs.append(row);return fs;}
 const old=document.getElementById('red').closest('.rgb');old.before(rgb);
 rgb.append(group('RGB',['red','green','blue'],'apply-rgb','pattern-rgb-fields'),group('Gray · 灰阶',['gray'],'apply-gray','pattern-gray-fields'));
 if(!old.children.length)old.remove();
 document.getElementById('back').closest('label').after(document.getElementById('apply-back'));
 const status=document.createElement('p');status.id='pattern-apply-status';status.setAttribute('role','status');status.textContent='RGB 与 Gray 独立保存；点击对应应用按钮发送。';rgb.append(status);
 document.querySelector('.pattern-apply').remove();
 for(const [id,mode] of [['apply-rgb','rgb'],['apply-gray','gray']])document.getElementById(id).onclick=safe(async()=>{
  const ids=mode==='rgb'?['red','green','blue']:['gray'];const values=ids.map(id=>{const raw=document.getElementById(id).value;const n=Number(raw);if(!raw.trim()||!Number.isInteger(n)||n<0||n>255)throw Error('请输入 0–255 的整数。');return n;});
  await command('pattern.'+mode);status.textContent=(mode==='rgb'?'RGB：'+values.join(' / '):'Gray：'+values[0]+' → '+[values[0],values[0],values[0]].join(' / '))+'，原 C# 发送流程已返回。';
 });
 const chart=document.getElementById('chart'),tab=document.createElement('button');tab.id='measurement-sheet-tab';tab.type='button';tab.textContent='Sheet · 数据';tab.setAttribute('role','tab');tab.setAttribute('aria-selected','false');chart.querySelector('.chart-tab-spacer').before(tab);
 const view=document.createElement('div');view.id='measurement-sheet';view.className='chart-measure-sheet';view.hidden=true;
 view.innerHTML='<div class="measurement-toolbar"><span id="measurement-summary"></span><button id="measurement-export">导出当前 CSV</button><button id="measurement-open-original">原 Sheet ↗</button></div><div class="measurement-scroll"><table id="measurement-table"><thead></thead><tbody></tbody></table><p id="measurement-empty">等待实测数据</p></div><p class="measurement-note">与当前曲线共用 C# 原始采样点，不包含插值点。</p>';
 chart.querySelector('.chart-body').after(view);
 function showTable(on){view.hidden=!on;chart.querySelector('.chart-body').hidden=on;tab.classList.toggle('active',on);tab.setAttribute('aria-selected',String(on));chart.querySelector('[data-chart-view=current]').classList.toggle('active',!on);if(!on)renderChart();}
 tab.onclick=()=>showTable(true);chart.querySelector('[data-chart-view=current]').onclick=()=>showTable(false);
 document.getElementById('measurement-open-original').onclick=()=>{document.querySelector('[data-code-tab="sheet-view"]').click();};
 document.getElementById('measurement-export').onclick=safe(()=>command('chart.export'));
 const legacy=document.getElementById('sheet-view'),bar=document.createElement('div');bar.className='measurement-toolbar';bar.innerHTML='<span>原 Sheet · 多组实测结果</span><button id="sheet-export-all">导出原 Sheet</button><button id="sheet-clear-records">清空记录</button>';legacy.prepend(bar);const empty=document.createElement('p');empty.id='native-sheet-empty';empty.className='measurement-note';empty.textContent='原 Sheet 暂无实测记录。';bar.after(empty);
 document.getElementById('sheet-export-all').onclick=safe(()=>command('sheet.export'));document.getElementById('sheet-clear-records').onclick=safe(()=>command('sheet.clear'));
 const table=document.getElementById('native-sheet'),scroll=document.createElement('div');scroll.className='measurement-scroll';table.before(scroll);scroll.append(table);
 function render(){
  const authorized=!!state?.authorized,busy=!!state?.busy,points=authorized?(state.points??[]):[];
  document.getElementById('measurement-summary').textContent=(state?.test||'当前测试')+' · '+points.length+' 个原始点';
  const t=document.getElementById('measurement-table');t.tHead.replaceChildren();t.tBodies[0]?.remove();const head=t.createTHead().insertRow();for(const name of ['#','码值 / 原标签',(state?.metric||'测量值')+' / '+(state?.unit||'')]){const th=document.createElement('th');th.textContent=name;head.append(th);}const body=t.createTBody();points.forEach((p,i)=>{const row=body.insertRow();row.dataset.pointIndex=i;row.tabIndex=0;for(const value of [i+1,p.x,p.y])row.insertCell().textContent=String(value);row.onclick=()=>{selectedPoint=i;document.getElementById('chart-reading').textContent=p.x+' · '+state.metric+' '+p.y+' '+state.unit;document.getElementById('chart-reading').classList.add('pinned');highlight();};row.onkeydown=e=>{if(e.key==='Enter')row.click();};});
  document.getElementById('measurement-empty').hidden=!!points.length;document.getElementById('native-sheet-empty').hidden=!!(authorized&&state.sheet?.length);
  for(const id of ['measurement-export','sheet-export-all','sheet-clear-records'])document.getElementById(id).disabled=!authorized||busy||(id==='measurement-export'&&!points.length);
  // Lock device mutations while keeping local viewing, resizing, conversion and theme controls available.
  for(const el of document.querySelectorAll('[data-action],#run-head,#run-current,#recipe-format,#choose-control-file,#bold-recipe,#italic-recipe,.pattern-card')){
   const action=el.dataset.action;el.disabled=busy&&!['pause','reset','goto'].includes(action);
  }
  for(const el of document.querySelectorAll('#uart input[name=encoding],#ca input[name=mode]'))el.disabled=busy;
  for(const [id,key] of [['apply-rgb','red'],['apply-gray','gray'],['apply-back','back']])document.getElementById(id).disabled=!authorized||busy||state?.enabled?.['pattern.'+key]===false;
  highlight();
 }
 function highlight(){for(const tr of document.querySelectorAll('#measurement-table tbody tr'))tr.classList.toggle('selected',Number(tr.dataset.pointIndex)===selectedPoint);}
 addEventListener('native-state',render);addEventListener('native-point',highlight);render();
})();
