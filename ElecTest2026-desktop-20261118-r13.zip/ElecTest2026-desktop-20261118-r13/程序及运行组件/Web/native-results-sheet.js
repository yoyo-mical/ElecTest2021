'use strict';
(() => {
  const api=window.ElecMeasurements, chart=document.getElementById('chart');
  const legacy=document.createElement('div');legacy.id='measurement-all-view';legacy.className='chart-measure-sheet';legacy.hidden=true;
  if(!api||!chart)return;chart.append(legacy);
  const records=new Map(), edits=window.ElecMeasurementEdits;
  const retainedGroups=()=>structuredClone(state?.groups||[]);
  let current=api.snapshot(), sheetActive=false;
  const tab=document.createElement('button');
  tab.type='button';tab.id='measurement-sheet-tab';tab.setAttribute('role','tab');tab.setAttribute('aria-selected','false');tab.setAttribute('aria-controls','measurement-sheet');tab.textContent='Sheet · 当前组';
  chart.querySelector('.chart-tab-spacer').before(tab);
  const allTab=document.createElement('button');allTab.id='measurement-all-tab';allTab.type='button';allTab.textContent='全部测量组';allTab.setAttribute('role','tab');allTab.setAttribute('aria-selected','false');allTab.setAttribute('aria-controls','measurement-all-view');tab.after(allTab);
  const view=document.createElement('div');view.id='measurement-sheet';view.className='chart-measure-sheet';view.setAttribute('role','tabpanel');view.setAttribute('aria-labelledby',tab.id);view.hidden=true;
  view.innerHTML='<div class="measurement-toolbar"><span id="measurement-summary"></span><button type="button" id="measurement-export">导出当前 CSV</button><button type="button" id="measurement-open-original">全部测量组</button></div><div class="measurement-scroll"><table id="measurement-table"><thead></thead><tbody></tbody></table><p id="measurement-empty" hidden>当前曲线暂无样本。</p></div><p class="measurement-note">与当前曲线使用同一组原始点，不包含插值生成的点；</p>';
  const graph=chart.querySelector('.chart-body');graph.after(view);
  legacy.replaceChildren();
  legacy.innerHTML='<div class="measurement-toolbar"><span>全部测量组 · 参数码值 / 测量值</span><button type="button" id="sheet-export-all">导出全部 CSV</button><button type="button" id="sheet-clear-records">删除全部组</button></div><p class="measurement-note">沿用原版码值／测量值成对列；不同测试组并排保存。所有数值为原始测量值。</p><div class="measurement-scroll"><table id="measurement-all-table"><thead></thead><tbody></tbody></table><p id="measurement-all-empty" hidden>暂无保存记录，新一轮采样将重新记录。</p></div><p class="measurement-note" id="measurement-all-status" role="status"></p>';
  function element(tag,text){const e=document.createElement(tag);if(text!==undefined)e.textContent=String(text);return e;}
  function value(group,point){return point.y.toFixed(group.decimals);}
  function groupTitle(group){return groupLabel(group)+' · '+group.title;}
  const followKeys=new WeakMap(),followTargets=new WeakMap(),pendingScroll=new WeakSet();
  function followTable(table,key,row,column){
    if(followKeys.get(table)===key)return;followKeys.set(table,key);followTargets.set(table,{row,column});queueFollow(table);
  }
  function queueFollow(table){if(pendingScroll.has(table))return;pendingScroll.add(table);requestAnimationFrame(()=>{pendingScroll.delete(table);const scroll=table.closest('.measurement-scroll'),target=followTargets.get(table);if(!scroll||!scroll.clientHeight||!target)return;const row=table.tBodies[0].rows[target.row],cell=row?.cells[target.column];if(!cell)return;const box=scroll.getBoundingClientRect(),rect=cell.getBoundingClientRect();scroll.scrollTop+=rect.bottom-box.bottom;scroll.scrollLeft+=Math.max(0,rect.right-box.right);});}
  for(const table of [view.querySelector('table'),legacy.querySelector('table')])new ResizeObserver(()=>queueFollow(table)).observe(table.closest('.measurement-scroll'));
  function renderCurrent(){
    const table=document.getElementById('measurement-table'),scroll=table.closest('.measurement-scroll'),top=scroll.scrollTop,left=scroll.scrollLeft;const head=element('tr');
    ['序号',current.axisX,current.metric+' / '+current.unit,'标记'].forEach(x=>head.append(element('th',x)));
    table.tHead.replaceChildren(head);table.tBodies[0].replaceChildren();
    current.points.forEach((point,i)=>{
      const row=element('tr');row.dataset.pointIndex=String(i);row.tabIndex=0;row.classList.toggle('selected',i===current.selectedIndex);
      [point.index,point.x,value(current,point),i===current.points.length-1?'最新点':''].forEach(x=>row.append(element('td',x)));
      row.title='选择曲线中的同一个数据点';row.onclick=()=>api.selectPoint(i);row.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();api.selectPoint(i);}};
      table.tBodies[0].append(row);
    });
    scroll.scrollTop=top;scroll.scrollLeft=left;
    followTable(table,current.runId+'|'+current.points.length+'|'+current.points.at(-1)?.index,current.points.length-1,0);
    document.getElementById('measurement-summary').textContent=current.title+' · '+current.points.length+' 点';
    document.getElementById('measurement-empty').hidden=!!current.points.length;
    document.getElementById('measurement-export').disabled=!current.points.length||(!!state?.busy&&current.completed===false);
  }
  function renderAll(){
    const table=document.getElementById('measurement-all-table'),scroll=table.closest('.measurement-scroll'),top=scroll.scrollTop,left=scroll.scrollLeft;const groups=retainedGroups();const first=element('tr'),second=element('tr');
    const index=element('th','序号');index.rowSpan=2;first.append(index);
    groups.forEach(group=>{const header=element('th',groupTitle(group));header.colSpan=2;first.append(header);second.append(element('th',group.axisX),element('th',group.metric+' / '+group.unit));});
    table.tHead.replaceChildren(first,second);table.tBodies[0].replaceChildren();
    const count=groups.reduce((n,g)=>Math.max(n,g.points.length),0);
    for(let i=0;i<count;i++){
      const row=element('tr');row.append(element('td',i+1));
      groups.forEach(group=>{const point=group.points[i];row.append(element('td',point?point.x:''),element('td',point?value(group,point):''));});
      table.tBodies[0].append(row);
    }
    scroll.scrollTop=top;scroll.scrollLeft=left;
    const latest=groups.at(-1);followTable(table,groups.map(g=>g.runId+':'+g.points.length).join('|'),(latest?.points.length||0)-1,groups.length*2);
    document.getElementById('measurement-all-empty').hidden=!!groups.length;
    document.getElementById('sheet-export-all').disabled=!groups.length;
    document.getElementById('sheet-clear-records').disabled=!groups.some(g=>edits.canEdit(g.runId));document.getElementById('sheet-clear-records').textContent=state?.busy?'删除已结束组':'删除全部组';
    document.getElementById('measurement-all-status').textContent=groups.length+' 组 · '+count+' 行；删除会同步到曲线和导出，可撤销。';
    window.dispatchEvent(new Event('electest:sheet-groups'));
  }
  function update(snapshot){records.set(snapshot.runId,structuredClone(snapshot));current=api.snapshot();renderCurrent();renderAll();}
  function setSheet(on){sheetActive=on;view.hidden=!on;graph.hidden=on;tab.classList.toggle('active',on);tab.setAttribute('aria-selected',String(on));
    if(on)chart.querySelectorAll('[data-chart-view]').forEach(button=>{button.classList.remove('active');button.setAttribute('aria-selected','false');});
  }
  tab.onclick=()=>setSheet(true);
  chart.querySelectorAll('[data-chart-view]').forEach(button=>button.addEventListener('click',()=>setSheet(false)));
  document.querySelector('[data-action="reset"]').addEventListener('click',()=>setSheet(false));
  document.getElementById('measurement-open-original').onclick=()=>allTab.click();
  function csvCell(text){return '"'+String(text).replace(/"/g,'""')+'"';}
  function toCsv(scope){
    let rows=[];
    if(scope==='current'){
      rows=[['序号',current.axisX,current.metric+' / '+current.unit,'数据来源'],...current.points.map(p=>[p.index,p.x,value(current,p),'实测'])];
    }else{
      const groups=retainedGroups();if(!groups.length)return '';
      rows=[['序号',...groups.flatMap(g=>[groupTitle(g)+' / '+g.axisX,groupTitle(g)+' / '+g.metric+' / '+g.unit])]];
      const count=groups.reduce((n,g)=>Math.max(n,g.points.length),0);
      for(let i=0;i<count;i++)rows.push([i+1,...groups.flatMap(g=>g.points[i]?[g.points[i].x,value(g,g.points[i])]:['',''])]);
    }
    return '\uFEFF'+rows.map(row=>row.map(csvCell).join(',')).join('\r\n')+'\r\n';
  }
  function download(scope){native('results.export',{scope,runId:api.snapshot().runId}).catch(e=>notify(e.message));}
  document.getElementById('measurement-export').onclick=()=>download('current');
  document.getElementById('sheet-export-all').onclick=()=>download('all');
  document.getElementById('sheet-clear-records').onclick=()=>{if(!edits.canEdit())return;const ids=retainedGroups().filter(g=>edits.canEdit(g.runId)).map(g=>g.runId);if(!ids.length||!window.confirm('删除全部 '+ids.length+' 组测量结果？曲线和导出同步更新，可撤销。'))return;edits.deleteGroups(ids);};
  window.addEventListener('electest:measurements',e=>update(e.detail));
  window.addEventListener('electest:measurement-view',e=>{current=e.detail;renderCurrent();renderAll();});
  window.addEventListener('electest:measurements-cleared',()=>{records.clear();renderAll();});
  window.ElecMeasurementSheet=Object.freeze({toCsv,groupSnapshot:id=>{const raw=state?.allGroups?.find(g=>g.runId===Number(id));return raw?structuredClone(raw):null;},groups:()=>structuredClone(retainedGroups())});
  new ResizeObserver(()=>{const row=document.querySelector('#measurement-all-table thead tr');if(row&&row.offsetHeight)legacy.style.setProperty('--group-header-height',row.offsetHeight+'px');}).observe(document.getElementById('measurement-all-table'));
  new MutationObserver(()=>{document.getElementById('sheet-clear-records').disabled=!retainedGroups().some(g=>edits.canEdit(g.runId));}).observe(document.getElementById('run-state'),{childList:true,subtree:true,characterData:true});
  window.addEventListener('electest:measurements',()=>{document.getElementById('sheet-clear-records').disabled=!retainedGroups().some(g=>edits.canEdit(g.runId));});
  update(current);
})();
