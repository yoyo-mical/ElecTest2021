'use strict';
(() => {
 const panel=document.getElementById('recipe');
 for(const [id,name,min,max]of [['start-value','起始值',0,255],['end-value','结束值',0,255],['step-value','步长',1,100]]){
  const input=document.getElementById(id);input.min=String(min);input.max=String(max);input.step='1';const wrap=document.createElement('span');wrap.className='recipe-spin';input.before(wrap);wrap.append(input);const buttons=document.createElement('span');buttons.className='recipe-spin-buttons';wrap.append(buttons);
  function change(delta){if(running)return;const value=Number(input.value);if(!input.value.trim()||!Number.isInteger(value)||value<min||value>max){input.setAttribute('aria-invalid','true');input.focus();input.select();window.ElecRecipeValidation?.report(name+'需要 '+min+'–'+max+' 的整数');toast(name+'需要 '+min+'–'+max+' 的整数；未修改。');return;}input.value=String(Math.max(min,Math.min(max,value+delta)));input.removeAttribute('aria-invalid');input.dispatchEvent(new Event('input',{bubbles:true}));}
  for(const [symbol,word,delta]of [['▴','增加',1],['▾','减少',-1]]){const b=document.createElement('button');b.type='button';b.textContent=symbol;b.setAttribute('aria-label',name+word+'1');b.onclick=()=>change(delta);buttons.append(b);}
  input.addEventListener('keydown',e=>{if(e.key==='ArrowUp'||e.key==='ArrowDown'){e.preventDefault();change(e.key==='ArrowUp'?1:-1);}});input.addEventListener('input',()=>input.removeAttribute('aria-invalid'));
 }
})();
