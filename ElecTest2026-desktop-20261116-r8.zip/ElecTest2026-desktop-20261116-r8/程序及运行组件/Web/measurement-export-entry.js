'use strict';
// Visible panel-owned entry; delegates to the existing original-point CSV exporters.
(() => {
 const panel=document.getElementById('chart'),actions=panel.querySelector('.panel-actions'),current=document.getElementById('measurement-export'),all=document.getElementById('sheet-export-all');
 const wrap=document.createElement('div');wrap.className='measurement-export-entry';wrap.innerHTML='<button id="results-export" type="button" aria-haspopup="menu" aria-expanded="false" aria-controls="results-export-menu">导出数据 ▾</button><div id="results-export-menu" class="measurement-export-menu" role="menu" hidden><button id="results-export-current" type="button" role="menuitem">Chart1 当前组 CSV</button><button id="results-export-all" type="button" role="menuitem">全部测量组 CSV</button></div>';actions.prepend(wrap);
 const trigger=wrap.querySelector('#results-export'),menu=wrap.querySelector('#results-export-menu'),one=wrap.querySelector('#results-export-current'),many=wrap.querySelector('#results-export-all');
 function close(focus=false){menu.hidden=true;trigger.setAttribute('aria-expanded','false');if(focus)trigger.focus();}
 function sync(){one.disabled=current.disabled;many.disabled=all.disabled;}
 trigger.onclick=()=>{sync();const on=menu.hidden;menu.hidden=!on;trigger.setAttribute('aria-expanded',String(on));if(on)([one,many].find(e=>!e.disabled)||trigger).focus();};
 one.onclick=()=>{if(!current.disabled)current.click();close(true);};many.onclick=()=>{if(!all.disabled)all.click();close(true);};
 wrap.addEventListener('keydown',e=>{if(e.key==='Escape'&&!menu.hidden){e.preventDefault();e.stopPropagation();close(true);}if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();const buttons=[one,many].filter(x=>!x.disabled);if(buttons.length){const at=buttons.indexOf(document.activeElement);buttons[(at+(e.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length].focus();}}});
 document.addEventListener('pointerdown',e=>{if(!wrap.contains(e.target))close();});wrap.addEventListener('focusout',e=>{if(e.relatedTarget&&!wrap.contains(e.relatedTarget))close();});
 addEventListener('electest:measurements',sync);addEventListener('electest:sheet-groups',sync);new MutationObserver(()=>close()).observe(panel,{attributes:true,attributeFilter:['class']});sync();
})();
