'use strict';
// Real C# state adapter. This file creates no samples, timers or device bytes.
let serial=false,ca=false,running=false,sampling=false,recipeTextMode=false,rawCursor=0,rawSelectedLine=0,step=0,selected=0,rows=[];
let chartCompare=false,chartType='',pointCount=0,chartZoom=1,measurementRunId=0,viewedMeasurementRunId=null,historySelectedPoint=-1;
const chartSVG=document.getElementById('plot');
const toast=notify,lines=updateLines;
function rawLines(){return recipeText().split('\n');}
function stop(){return command('stop');}
function renderRows(){renderRecipe();}
const actions=window.actions={};
for(const [key,op]of Object.entries({connect:'serial.connect',scan:'serial.scan',measure:'meter.measure',download:'arm.download',format:'arm.format',comment:'arm.comment','delete-code':'arm.clear',add:'recipe.add',up:'recipe.up',down:'recipe.down','delete-row':'recipe.clear',import:'recipe.import','export-recipe':'recipe.export',run:'recipe.run',step:'recipe.step',pause:'pause',resume:'resume','clear-log':'serial.clear'}))actions[key]=()=>command(op);
actions['ca-connect']=()=>command(state?.meterConnected?'meter.disconnect':'meter.connect');
actions.reset=()=>{for(const p of $$('.panel.expanded'))p.classList.remove('expanded');$('#workspace').style.cssText='';notify('已恢复布局；脚本、配方和测量数据保留。');};
function liveGroup(){return state?.allGroups?.find(g=>g.runId===state.currentRunId)||state?.groups?.find(g=>g.runId===state.currentRunId)||null;}
function viewGroup(){return viewedMeasurementRunId===null?liveGroup():state?.allGroups?.find(g=>g.runId===viewedMeasurementRunId)||state?.groups?.find(g=>g.runId===viewedMeasurementRunId)||null;}
function snapshot(){const g=viewGroup();return g?{...structuredClone(g),selectedIndex:selectedPoint,sampling:!!running}:{runId:0,title:'等待测量',testKey:'',metric:'Lv',unit:'cd/m²',axisX:'参数码值',axisY:'测量值',hex:true,decimals:4,points:[],selectedIndex:-1,expectedCount:0};}
function measurementSnapshot(){return snapshot();}
function measurementRawSnapshot(){return liveGroup()?structuredClone(liveGroup()):snapshot();}
function chartViewData(){const g=snapshot(),points=g.points,data={...g,axisY:g.metric+' / '+g.unit,x:points.map(p=>g.hex?parseInt(p.x,16):Number(p.x)),y:points.map(p=>p.y),previous:points.map(p=>p.y)};if(!points.length){data.x=[0];data.y=[0];data.previous=[0];}return {data,sourceIndices:points.map((p,i)=>i),count:points.length,selectedIndex:Math.max(0,Math.min(points.length-1,selectedPoint<0?points.length-1:selectedPoint)),originalLength:g.expectedCount||g.sourcePointCount||points.length,deleted:g.deleted,historical:viewedMeasurementRunId!==null};}
window.ElecMeasurements=Object.freeze({snapshot,viewedRunId:()=>viewedMeasurementRunId,viewGroup(id){if(id!==null&&!state?.allGroups?.some(g=>g.runId===Number(id)))return false;viewedMeasurementRunId=id===null?null:Number(id);selectedPoint=-1;chartZoom=1;renderChart();return true;},selectPoint(i){if(!Number.isInteger(i)||i<0||i>=snapshot().points.length)return;selectedPoint=i;$('#chart-reading').classList.add('pinned');renderChart();}});
function resultEdit(operation,args={}){if(!window.ElecMeasurementEdits.canEdit())return false;native(operation,args).then(r=>{applyState(r.state);dispatchEvent(new Event('electest:measurement-edits'));}).catch(e=>notify(e.message));return true;}
window.ElecMeasurementEdits=Object.freeze({canEdit:()=>!state?.busy,filter:x=>structuredClone(x),isGroupDeleted:id=>!!state?.allGroups?.find(g=>String(g.runId)===String(id))?.deleted,indices:(id,n)=>Array.from({length:n},(_,i)=>i),deleteGroups:ids=>resultEdit('results.deleteGroups',{groupIds:ids.map(Number)}),deletePoints:(id,ids)=>resultEdit('results.deletePoints',{runId:Number(id),pointIds:ids}),undo:()=>resultEdit('results.undo'),state:()=>({undoCount:state?.resultUndoCount||0,undoLimit:20})});
addEventListener('native-state',()=>{serial=!!state?.serialConnected;ca=!!state?.meterConnected;running=!!state?.runningRecipe;sampling=!!state?.busy;chartType=state?.test?.toLowerCase()||'';pointCount=state?.points?.length||0;measurementRunId=state?.currentRunId||0;rawCursor=state?.currentLine||0;step=rawCursor;renderChart();dispatchEvent(new Event('electest:sheet-groups'));});
