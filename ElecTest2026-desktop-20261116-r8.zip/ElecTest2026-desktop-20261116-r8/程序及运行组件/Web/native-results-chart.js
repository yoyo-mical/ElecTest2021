'use strict';
(() => {
 const chart=document.getElementById('chart'),api=window.ElecMeasurements,sheets=window.ElecMeasurementSheet,graph=chart.querySelector('.chart-body'),sheet=document.getElementById('measurement-sheet');
 const currentTab=chart.querySelector('[data-chart-view=current]'),galleryTab=chart.querySelector('[data-chart-view=compare]'),sheetTab=document.getElementById('measurement-sheet-tab'),allTab=document.getElementById('measurement-all-tab'),allView=document.getElementById('measurement-all-view');
 galleryTab.textContent='Chart2 · 多图';galleryTab.title='本次会话已记录的各测试组，每组独立显示';galleryTab.dataset.chartView='gallery';
 const bothTab=document.createElement('button');bothTab.id='chart-combined-tab';bothTab.type='button';bothTab.textContent='曲线 + Sheet';bothTab.setAttribute('role','tab');bothTab.setAttribute('aria-selected','false');sheetTab.after(bothTab);
 const workspace=document.createElement('div');workspace.id='chart-current-workspace';workspace.dataset.mode='curve';graph.before(workspace);workspace.append(graph,sheet);
 const gallery=document.createElement('div');gallery.id='chart-gallery';gallery.className='chart-gallery';gallery.hidden=true;workspace.after(gallery);
 gallery.innerHTML='<div class="measurement-toolbar"><span id="chart-gallery-summary"></span><button id="chart-gallery-export" type="button">导出全部测量组 CSV</button></div><div id="chart-gallery-grid" class="chart-gallery-grid"></div><p class="measurement-note">每组单独保留参数、单位和原始点；不同单位不叠加。未导出数据仅保留在本次软件运行内。</p>';
 let mode='curve',drawQueued=false;const plots=new Map();const plotResize=new ResizeObserver(queueDraw);
 const groups=()=>sheets.groups().filter(g=>g.points.length);
 function setMode(next,expand=true){
  if(expand&&['both','gallery','manage'].includes(next)&&!chart.classList.contains('expanded'))chart.querySelector('[data-expand]').click();
  mode=next;chart.dataset.view=next;workspace.dataset.mode=next;workspace.hidden=['gallery','all','manage'].includes(next);gallery.hidden=next!=='gallery';allView.hidden=next!=='all';const manager=document.getElementById('results-manager');if(manager)manager.hidden=next!=='manage';const manageTab=document.getElementById('results-manage-tab');if(manageTab){manageTab.classList.toggle('active',next==='manage');manageTab.setAttribute('aria-selected',String(next==='manage'));}graph.hidden=!['curve','both'].includes(next);sheet.hidden=!['sheet','both'].includes(next);
  for(const [tab,name] of [[currentTab,'curve'],[sheetTab,'sheet'],[bothTab,'both'],[galleryTab,'gallery'],[allTab,'all']]){tab.classList.toggle('active',next===name);tab.setAttribute('aria-selected',String(next===name));}
  chartCompare=false;
  if(next==='gallery')renderGallery();dispatchEvent(new CustomEvent('electest:results-mode',{detail:{mode:next}}));
  requestAnimationFrame(()=>{if(mode!=='gallery')renderChart();else queueDraw();});
 }
 currentTab.onclick=()=>setMode('curve');galleryTab.onclick=()=>setMode('gallery');sheetTab.onclick=()=>setMode('sheet');bothTab.onclick=()=>setMode('both');allTab.onclick=()=>setMode('all');
 document.getElementById('chart-gallery-export').onclick=()=>document.getElementById('sheet-export-all').click();
 function element(tag,cls,text){const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=String(text);return e;}
 function renderGallery(){
  const records=groups(),grid=document.getElementById('chart-gallery-grid');plotResize.disconnect();grid.replaceChildren();plots.clear();document.getElementById('chart-gallery-summary').textContent=records.length+' 组结果 · 独立坐标 / 单位';document.getElementById('chart-gallery-export').disabled=!records.length;
  if(!records.length){grid.append(element('p','gallery-empty','暂无已记录的测试结果。采样后在这里逐组显示。'));return;}
  for(const group of records){const card=element('section','result-chart-card');card.dataset.runId=group.runId;card.dataset.testKey=group.testKey;const header=element('div','result-chart-header');header.append(element('h3','',group.title),element('span','result-group-id','第 '+group.runId+' 组'));const meta=element('div','result-chart-meta');meta.append(element('span','',group.metric+' / '+group.unit),element('span','',group.points.length+' 个原始点'));const plot=element('div','result-chart-plot');card.append(header,meta,plot);grid.append(card);plots.set(plot,group);plotResize.observe(plot);}
  queueDraw();
 }
 function svg(tag,attrs={},text){const e=document.createElementNS('http://www.w3.org/2000/svg',tag);for(const [k,v]of Object.entries(attrs))e.setAttribute(k,String(v));if(text!==undefined)e.textContent=String(text);return e;}
 function draw(plot,g){
  const w=Math.max(280,plot.clientWidth),h=Math.max(140,plot.clientHeight);const s=svg('svg',{viewBox:`0 0 ${w} ${h}`,role:'img','aria-label':g.title+'，'+g.metric+'，单位'+g.unit});const b={l:49,r:w-14,t:14,b:h-42};const ys=g.points.map(p=>p.y);let lo=Math.min(...ys),hi=Math.max(...ys),pad=(hi-lo)*.12||1;lo-=pad;hi+=pad;if(g.metric==='Lv'&&Math.min(...ys)>=0)lo=Math.max(0,lo);const xs=g.points.map(p=>g.hex?parseInt(p.x,16):Number(p.x)),xlo=Math.min(...xs),xhi=Math.max(...xs),numeric=xs.every(Number.isFinite)&&xhi>xlo,X=i=>g.points.length===1?(b.l+b.r)/2:numeric?b.l+(xs[i]-xlo)*(b.r-b.l)/(xhi-xlo):b.l+i*(b.r-b.l)/(g.points.length-1),Y=y=>b.b-(y-lo)*(b.b-b.t)/(hi-lo);
  for(let i=0;i<=3;i++){const y=b.t+i*(b.b-b.t)/3;s.append(svg('line',{x1:b.l,x2:b.r,y1:y,y2:y,stroke:'var(--chart-grid)'}),svg('text',{x:b.l-7,y:y+4,'text-anchor':'end',fill:'var(--theme-muted)','font-size':10},(hi-i*(hi-lo)/3).toFixed(g.decimals)));}
  const ticks=Math.min(4,g.points.length);for(let i=0;i<ticks;i++){const j=ticks===1?0:Math.round(i*(g.points.length-1)/(ticks-1));s.append(svg('text',{x:X(j),y:b.b+17,'text-anchor':'middle',fill:'var(--theme-muted)','font-size':10},(g.hex?'0x':'')+g.points[j].x));}
  if(g.points.length>1)s.append(svg('polyline',{points:g.points.map((p,i)=>X(i)+','+Y(p.y)).join(' '),fill:'none',stroke:'var(--chart-line)','stroke-width':1.8}));
  g.points.forEach((p,i)=>{const c=svg('circle',{cx:X(i),cy:Y(p.y),r:i===g.points.length-1?3.5:2.8,fill:i===g.points.length-1?'var(--chart-line)':'var(--theme-surface)',stroke:'var(--chart-line)','stroke-width':1.3});c.append(svg('title',{},p.x+' · '+p.y.toFixed(g.decimals)+' '+g.unit));s.append(c);});s.append(svg('text',{x:(b.l+b.r)/2,y:h-5,'text-anchor':'middle',fill:'var(--theme-muted)','font-size':10},g.axisX));plot.replaceChildren(s);
 }
 function queueDraw(){if(drawQueued)return;drawQueued=true;requestAnimationFrame(()=>{drawQueued=false;if(mode==='gallery')for(const [plot,g]of plots)draw(plot,g);});}
 new ResizeObserver(queueDraw).observe(document.getElementById('chart-gallery-grid'));
 addEventListener('electest:sheet-groups',()=>{if(mode==='gallery')renderGallery();});
 new MutationObserver(()=>{queueDraw();requestAnimationFrame(()=>{if(mode!=='gallery')renderChart();});}).observe(chart,{attributes:true,attributeFilter:['class']});
 document.querySelector('[data-action=reset]').addEventListener('click',()=>setMode('curve',false));
 window.ElecChartWorkspace=Object.freeze({show:setMode,mode:()=>mode});
 setMode('curve',false);
})();
