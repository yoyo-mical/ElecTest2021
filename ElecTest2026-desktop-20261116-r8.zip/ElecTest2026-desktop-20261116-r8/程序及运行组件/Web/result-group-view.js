'use strict';
(() => {
 const chart=document.getElementById('chart'),api=window.ElecMeasurements,tabs=chart.querySelector('.chart-tabs');
 const label=document.createElement('label');label.className='result-single-group';
 const select=document.createElement('select');select.id='result-single-group';select.setAttribute('aria-label','单图测量组');label.append(select);tabs.querySelector('.chart-tab-spacer').after(label);
 let signature='';
 function sync(){const groups=window.ElecMeasurementSheet.groups(),id=api.viewedRunId(),key=JSON.stringify([id,groups.map(g=>[g.runId,g.title,g.deleted])]);if(key!==signature){signature=key;const live=document.createElement('option');live.value='live';live.textContent='当前采集组';select.replaceChildren(live);for(const g of groups){const option=document.createElement('option');option.value=String(g.runId);option.textContent='第 '+g.runId+' 组 · '+g.title;select.append(option);}if(id!==null&&!groups.some(g=>String(g.runId)===String(id))){const deleted=document.createElement('option');deleted.value=String(id);deleted.textContent='第 '+id+' 组 · 已删除';select.append(deleted);}select.value=id===null?'live':String(id);}
  const mode=window.ElecChartWorkspace.mode();label.hidden=!['curve','sheet','both'].includes(mode);document.getElementById('results-export-current').textContent=id===null?'Chart1 当前组 CSV':'第 '+id+' 组 CSV';
 }
 select.onchange=()=>{api.viewGroup(select.value==='live'?null:Number(select.value));};
 addEventListener('electest:measurement-view',sync);addEventListener('electest:sheet-groups',sync);addEventListener('electest:results-mode',sync);sync();
})();
