'use strict';
(()=>{
 const sampleName='示例项目 · 图案灰阶';
 const sampleTest='黑框背景灰阶 · 3 点';
 const sample={script:'// 示例只扫描图案背景灰阶，不写入 GIP Code。',recipe:'MultiScan 300 Lv 01 GRAY 40;80;C0'};
 let catalog={};
 const catalogKey='electest.recipe.catalog.v1';
 try{catalog=JSON.parse(localStorage.getItem(catalogKey)||'{}');}catch{}
 const product=document.createElement('select');
 product.setAttribute('aria-label','产品项目');
 product.add(new Option('选择产品项目',''));
 function listProducts(){product.replaceChildren(new Option('选择产品项目',''),...[...new Set([sampleName,...Object.keys(catalog)])].map(name=>new Option(name)));}
 listProducts();
 const top=document.createElement('label');
 top.className='lab-product';top.append(product);
 const file=document.createElement('input');file.type='file';file.accept='.json';file.hidden=true;
 const browse=document.createElement('button');browse.type='button';browse.textContent='导入项目配置';
 browse.onclick=()=>file.click();
 file.onchange=async()=>{
  const selected=file.files[0];file.value='';
  if(!selected||state?.busy)return;
  try{
   if(selected.size>4*1024*1024)throw Error('项目配置文件最多 4 MB。');
   const incoming=JSON.parse(await selected.text());
   if(state?.busy)throw Error("请在配方停止后导入项目。");
   const validated=Object.create(null);
   const projects=Object.entries(incoming.products||{});
   if(!projects.length)throw Error('项目配置缺少 products。');
   for(const [name,tests] of projects){
    const mapped=Object.create(null),entries=Object.entries(tests||{});
    if(!name.trim()||!entries.length)throw Error('产品名称或测试项目为空。');
    for(const [title,template] of entries){
     if(!title.trim()||typeof template?.script!=='string'||typeof template.recipe!=='string'||
        !template.script.trim()||!template.recipe.trim())throw Error('项目配置缺少 Code 或 Recipe：'+title);
     mapped[title]={script:template.script,recipe:template.recipe};
    }
    validated[name]=mapped;
   }
   localStorage.setItem(catalogKey,JSON.stringify(validated));catalog=validated;
   listProducts();loadTests();notify('已导入项目配置。');
  }catch(error){notify(error.message);}
 };
 top.append(browse,file);
 document.querySelector('.top-right').prepend(top);
 const recipe=document.querySelector('#recipe'),body=recipe.querySelector('.body');
 const workspace=recipe.querySelector('.recipe-workspace');
 const context=document.createElement('div');context.className='lab-context';
 context.innerHTML='<label>测试项目 <select id="lab-test" disabled></select></label><button type="button" id="lab-open">添加扫描步骤</button><button type="button" id="lab-project-save" class="primary" disabled>保存到当前测试项目</button>';
 recipe.querySelector(".panel-actions").before(context);
 const lab=document.createElement('fieldset');lab.id='recipe-lab';lab.hidden=true;
 lab.innerHTML='<legend>Code参数</legend><div class="lab-tools"><label>测量 <select id="lab-metric"><option>Flicker</option><option value="Lv">亮度</option></select></label><label>稳定时间 <input id="lab-delay" type="number" min="0" max="1000000" value="300"> ms</label><label>配置方式 <select id="lab-mode"><option>同步步进</option><option>指定组合</option><option>自动遍历</option></select></label><button type="button" id="lab-build">生成测点表</button><button type="button" id="lab-save">保存步骤</button></div><div id="lab-settings"></div><small id="lab-status" role="status"></small>';
 const points=document.createElement('section');points.className='lab-points';points.hidden=true;
 points.innerHTML='<b>当前步骤测点表</b><div id="lab-entry"></div><div id="lab-result"></div><small id="lab-frame"></small>';
 const split=document.createElement('div');split.className='lab-split';split.hidden=true;split.tabIndex=0;split.setAttribute('role','separator');split.setAttribute('aria-label','调整测点表宽度');split.setAttribute('aria-orientation','vertical');
 workspace.append(split,points);
 const test=context.querySelector('#lab-test'),mode=lab.querySelector('#lab-mode'),settings=lab.querySelector('#lab-settings'),result=points.querySelector('#lab-result'),status=lab.querySelector('#lab-status'),entry=points.querySelector('#lab-entry');
 const metric=lab.querySelector('#lab-metric'),delay=lab.querySelector('#lab-delay');
 const stepSettings=body.querySelector('.recipe-settings');
 const extras=body.querySelector('.control-inputs');
 const modes=recipe.querySelector('.recipe-modes');
 const arrangeTools=recipe.querySelector('.recipe-arrange-tools');
 function group(name){
  const box=document.createElement('fieldset');box.className='lab-group';
  const legend=document.createElement('legend');legend.textContent=name;box.append(legend);
  return box;
 }
 const stepGroup=group('步骤参数'),extraGroup=group('附加参数');
 for(const box of [lab,stepGroup,extraGroup]){
  const legend=box.querySelector('legend'),title=legend.textContent;
  const toggle=document.createElement('button');toggle.type='button';
  toggle.className='lab-group-toggle';toggle.textContent=title;toggle.setAttribute('aria-expanded','true');
  toggle.onclick=()=>toggle.setAttribute('aria-expanded',String(!box.classList.toggle('lab-collapsed')));
  legend.replaceChildren(toggle);
 }
 let current=null;
 function place(){
  const full=recipe.classList.contains('expanded');
  (full?workspace.querySelector('.recipe-workspace-left'):body).prepend(lab);
  if(full){
   workspace.append(points);
   const left=workspace.querySelector('.recipe-workspace-left');
   left.append(stepGroup,extraGroup);stepGroup.append(stepSettings);extraGroup.append(extras);
   arrangeTools?.append(modes);
  }else{
   lab.after(points);stepGroup.remove();extraGroup.remove();
  }
  split.hidden=!full||!current;points.hidden=!current;lab.hidden=!current;
  recipe.classList.toggle('lab-editing',!!current);
 }
 new MutationObserver(()=>{const full=recipe.classList.contains('expanded');if(full!==(points.parentElement===workspace)){if(full&&!current&&!state?.busy)openScan(null);else place();}}).observe(recipe,{attributes:true,attributeFilter:['class']});
 function width(delta){const w=workspace.clientWidth;if(w)workspace.style.setProperty('--lab-points',Math.max(220,Math.min(w*.50,points.offsetWidth+delta))+'px');}
 split.onpointerdown=e=>{if(e.button===0)split.setPointerCapture(e.pointerId);};
 split.onpointermove=e=>{if(split.hasPointerCapture(e.pointerId))width(-e.movementX);};
 split.onkeydown=e=>{if(['ArrowLeft','ArrowRight'].includes(e.key)){e.preventDefault();width(e.key==='ArrowLeft'?20:-20);}};
 let rows=[],config={axes:[]},loadedProduct='',loadedTest='',loadedScript='',loadedRecipe='';
 const gip=['CKH','VGH','VGL','VCOM','CKV','EQ'];
 const patterns={'纯色灰':'纯色灰阶','三分之一黑框':'背景灰阶','三分之一白框':'背景灰阶'};
 let pattern='纯色灰';
 function fillAxes(saved){
  axisPicker.replaceChildren();
  const gipBox=document.createElement('div'),patternBox=document.createElement('div');
  gipBox.className=patternBox.className='lab-code-category';
  const gipTitle=document.createElement('b');gipTitle.textContent='GIP Code';gipBox.append(gipTitle);
  const patternTitle=document.createElement('b');patternTitle.textContent='Pattern Code';patternBox.append(patternTitle);
  const select=document.createElement('select');select.setAttribute('aria-label','扫描图案');
  Object.keys(patterns).forEach(name=>select.add(new Option(name)));select.value=pattern;
  patternBox.append(select);
  axisPicker.append(gipBox,patternBox);
  const defaults=saved?.axes||config.axes;
  gip.forEach(axis=>addAxis(axis,gipBox,defaults));
  addAxis(patterns[pattern],patternBox,defaults);
  select.onchange=()=>{

   const checked=activeAxes().filter(axis=>!isGray(axis));
   if(activeAxes().some(isGray))checked.push(patterns[select.value]);
   pattern=select.value;fillAxes({axes:checked});paintSettings();
  };
 }
 const axisPicker=document.createElement('div');axisPicker.className='lab-axes';settings.before(axisPicker);
 function activeAxes(){return [...axisPicker.querySelectorAll('input:checked')].map(e=>e.value);}
 function isGray(axis){return axis.endsWith('灰阶');}
 const format=(axis,n)=>isGray(axis)?String(n):n.toString(16).toUpperCase().padStart(2,'0');
 function parse(axis,value){
  const v=value.trim();
  if(!(isGray(axis)?/^\d{1,3}$/:/^(?:0x)?[\da-f]{1,2}$/i).test(v))throw Error(axis+' 数值格式错误');
  const n=parseInt(v,isGray(axis)?10:16);if(n>255)throw Error(axis+' 超出范围');return n;
 }
 function resetTable(){rows=[];result.replaceChildren();points.querySelector('#lab-frame').textContent='';}
 function paintSettings(){
  resetTable();settings.replaceChildren();entry.replaceChildren();

  const selected=activeAxes();
  if(mode.value==='指定组合'){
   const input=document.createElement('textarea');input.rows=2;
   input.setAttribute('aria-label','指定组合');
   input.placeholder='每行一组，按列用空格、逗号或 Tab 分隔';
   input.value=[0,1,2].map(i=>selected.map(a=>format(a,isGray(a)?64+i*64:1+i)).join('\t')).join('\n');
   input.addEventListener('input',()=>{resetTable();});
   const heading=document.createElement('p');heading.textContent=selected.map(a=>a+(isGray(a)?'（十进制）':'（HEX）')).join(' / ');
   const hint=document.createElement('small');
   hint.textContent='从 Excel 复制数据行并粘贴到这里。每行一个测点，不含表头。支持 Tab、逗号或空格分隔。';
   entry.append(heading,hint,input);return;
  }
  for(const axis of selected){
   const line=document.createElement('div');line.className='lab-axis';
   const title=document.createElement('b');title.textContent=axis+(isGray(axis)?' · DEC':' · HEX');line.append(title);
   for(const [label,value] of [['起始',isGray(axis)?'64':'01'],['结束',isGray(axis)?'192':'03'],['步长',isGray(axis)?'64':'01']]){
    const field=document.createElement('label');field.textContent=label+' ';const input=document.createElement('input');
    input.value=value;input.setAttribute('aria-label',axis+' '+label);input.addEventListener('input',()=>{resetTable();});field.append(input);line.append(field);
   }
   settings.append(line);
  }
 }
 function loadTests(){
  test.replaceChildren(new Option('选择测试项目',''));
  Object.keys(catalog[product.value]||(product.value===sampleName?{[sampleTest]:sample}:{})).forEach(name=>test.add(new Option(name)));
  context.querySelector('#lab-project-save').disabled=true;
  test.disabled=!product.value;current=null;place();resetTable();
 }
 product.onchange=loadTests;loadTests();
 test.onchange=()=>{
  if(!test.value||state?.busy)return;
  const template=catalog[product.value]?.[test.value]||(product.value===sampleName&&test.value===sampleTest?sample:null);if(!template)return;
  if((document.querySelector('#editor').value!==loadedScript||recipeText()!==loadedRecipe)
     &&(recipeText().trim()||document.querySelector('#editor').value.trim())
     &&!confirm('载入会替换当前 Code 和配方。继续载入？')){
   product.value=loadedProduct;loadTests();test.value=loadedTest;
   context.querySelector('#lab-project-save').disabled=!loadedTest;return;
  }
  loadedProduct=product.value;loadedTest=test.value;
  loadedScript=template.script;loadedRecipe=template.recipe;
  const editor=document.querySelector('#editor');
  editor.value=loadedScript;editor.dispatchEvent(new Event('input',{bubbles:true}));
  renderRichText([{text:loadedRecipe}]);recipeDirty=true;
  closeScan();context.querySelector('#lab-project-save').disabled=false;
  const scanLine=loadedRecipe.split('\n').findIndex(line=>parseStep(line));
  if(scanLine>=0){selectedLine=scanLine;openScan(scanLine);renderRecipe();}
 };
 function addAxis(axis,parent,defaults){
  const label=document.createElement('label'),box=document.createElement('input');box.type='checkbox';box.value=axis;box.checked=defaults.includes(axis);box.onchange=()=>{paintSettings();};label.append(box,axis);parent.append(label);
 }
 mode.onchange=()=>{paintSettings();};
 function build(){
  const selected=activeAxes();if(!selected.length)throw Error('请至少选择一个扫描参数。');
  if(mode.value==='指定组合'){
   rows=entry.querySelector('textarea').value.trim().split(/\r?\n/).filter(l=>l.trim()).map((line,i)=>{
    const cols=line.trim().split(/[\s,，]+/);if(cols.length!==selected.length)throw Error('第 '+(i+1)+' 行列数与所选参数不一致');
    return cols.map((v,k)=>parse(selected[k],v));
   });
  }else{
   const lists=[...settings.querySelectorAll('.lab-axis')].map((line,i)=>{
    const [start,end,step]=[...line.querySelectorAll('input')].map(input=>parse(selected[i],input.value));
    if(!step)throw Error('步长必须大于 0');
    const direction=start<=end?1:-1;
    return Array.from({length:1+Math.floor(Math.abs(end-start)/step)},(_,j)=>start+j*step*direction);
   });
   if(mode.value==='同步步进'){
    if(lists.some(list=>list.length!==lists[0].length))throw Error('同步步进要求各轴档位数相同。');
    rows=lists[0].map((_,i)=>lists.map(list=>list[i]));
   }else{
    if(lists.reduce((n,list)=>n*list.length,1)>4096)throw Error('每个扫描步骤最多 4096 点，请缩小范围。');
    rows=lists.reduce((acc,list)=>acc.flatMap(row=>list.map(v=>[...row,v])),[[]]);
   }
  }
  if(!rows.length||rows.length>4096)throw Error('请输入 1–4096 个测点。');
  const table=document.createElement('table'),head=table.createTHead().insertRow();
  ['测点',...selected].forEach(value=>{const th=document.createElement('th');th.textContent=value;head.append(th);});
  const body=table.createTBody();
  rows.forEach((row,i)=>{const tr=body.insertRow();[i+1,...row.map((v,k)=>format(selected[k],v))].forEach(v=>tr.insertCell().textContent=v);});
  result.replaceChildren(table);status.textContent='共 '+rows.length+' 点，按表格顺序执行。';
 }
 function action(fn){try{fn();}catch(e){resetTable();status.textContent=e.message;}}
 lab.querySelector('#lab-build').onclick=()=>action(build);
 function closeScan(){current=null;place();}
 function parseStep(line){
  const match=/^MultiScan (\d+) (Lv|Flicker) (00|01|07|-) ([A-Z,]+) ([\dA-F;]+)(?: ([A-Za-z0-9+/=]+))?$/.exec(line||'');
  if(!match)return null;
  const names=match[4].split(',');
  let saved={};
  try{saved=JSON.parse(atob(match[6]||''));}catch{}
  return {delay:match[1],metric:match[2],pattern:saved.pattern||({'01':'三分之一黑框','07':'三分之一白框'})[match[3]]||'纯色灰',
   axes:names.map(axis=>axis==='GRAY'?(match[3]==='00'?'纯色灰阶':'背景灰阶'):axis),
   mode:mode.options[saved.mode]?.value||'指定组合',values:saved.values,
   rows:match[5].split(';').map(row=>row.match(/../g).map(v=>parseInt(v,16)))};
 }
 const steps=document.querySelector('#recipe-rows');
 function saveScan(){
  build();
  if(!delay.validity.valid||delay.value==='')throw Error('请填写有效的稳定时间。');
  const selected=activeAxes();
  const axes=selected.map(axis=>isGray(axis)?'GRAY':axis);
  const code=axes.includes('GRAY')?({'纯色灰':'00','三分之一黑框':'01','三分之一白框':'07'})[pattern]:'-';
  const data=rows.map(row=>row.map(v=>v.toString(16).toUpperCase().padStart(2,'0')).join('')).join(';');
  const meta=btoa(JSON.stringify({mode:mode.selectedIndex,values:[...settings.querySelectorAll('input')].map(e=>e.value)}));
  const line=['MultiScan',delay.value,metric.value,code,axes.join(','),data,meta].join(' ');
  const lines=recipeText().trim()?recipeText().split('\n'):[];
  const at=current.line;
  if(at!==null&&lines[at]!==current.source)throw Error('配方行已变化，请重新选中需要编辑的步骤。');
  const offset=at===null?recipeText().length:lines.slice(0,at).reduce((n,text)=>n+text.length+1,0);
  const cut=offset+(at===null?0:lines[at].length);
  const left=[],right=[];
  let position=0;
  for(const run of recipeRuns()){
   const end=position+run.text.length;
   if(position<offset)left.push({...run,text:run.text.slice(0,offset-position)});
   if(end>cut)right.push({...run,text:run.text.slice(Math.max(0,cut-position))});
   position=end;
  }
  const needsBreak=at===null&&offset>0&&!recipeText().endsWith('\n');
  current={line:at??(needsBreak?lines.length:Math.max(0,lines.length-1)),source:line};
  selectedLine=current.line;
  rawSelection={selectionStart:offset+(needsBreak?1:0),selectionLength:0};
  renderRichText([...left,{text:(needsBreak?'\n':'')+line},...right]);recipeDirty=true;
  status.textContent='已应用到配方 · '+rows.length+' 点';
 }
 context.querySelector('#lab-project-save').onclick=()=>{
  if(state?.busy||!loadedProduct||!loadedTest||product.value!==loadedProduct||test.value!==loadedTest)return;
  try{
   const script=document.querySelector('#editor').value,recipe=recipeText();
   const updated={...catalog,[loadedProduct]:{...catalog[loadedProduct],[loadedTest]:{script,recipe}}};
   localStorage.setItem(catalogKey,JSON.stringify(updated));catalog=updated;
   loadedScript=script;loadedRecipe=recipe;notify('已保存到 '+loadedProduct+' / '+loadedTest);
  }catch(error){notify(error.message);}
 };
 function openScan(line){
  const source=line===null?'':recipeText().split('\n')[line];
  const saved=parseStep(source);
  current={line,source};
  config={axes:saved?.axes||['VGH']};
  pattern=saved?.pattern||'纯色灰';
  metric.value=saved?.metric||'Flicker';delay.value=saved?.delay||'300';
  mode.value=saved?.mode||'同步步进';fillAxes(saved);place();paintSettings();
  if(saved){
   if(saved.values)settings.querySelectorAll('input').forEach((e,i)=>e.value=saved.values[i]??e.value);
   if(mode.value==='指定组合')entry.querySelector('textarea').value=saved.rows.map(row=>row.map((v,i)=>format(saved.axes[i],v)).join('\t')).join('\n');
   action(build);
  }
 }
 context.querySelector('#lab-open').onclick=()=>{if(!state?.busy)openScan(null);};
 lab.querySelector('#lab-save').onclick=()=>{if(!state?.busy)action(saveScan);};
 const render=renderRecipe;renderRecipe=function(){
  render();const lines=recipeText().split('\n');
  [...steps.rows].forEach((row,i)=>{
   const scan=parseStep(lines[i]);
   if(!scan)return;
   row.cells[1].textContent='多参数扫描';
   row.cells[2].textContent=scan.axes.map(axis=>isGray(axis)?scan.pattern+' · '+axis:axis).join(' + ')+' · '+scan.mode+' · '+scan.rows.length+' 点';
   row.cells[5].textContent=scan.delay+' ms';
  });
 };
 steps.addEventListener('click',e=>{
  const row=e.target.closest('tr');if(!row||state?.busy)return;
  const i=row.sectionRowIndex;
  if(parseStep(recipeText().split('\n')[i]))openScan(i);else closeScan();
 });
 let lastPoint=0,lastLine=-1;
 addEventListener('native-state',()=>{
  const busy=!!state?.busy;
  product.disabled=test.disabled=busy;
  if(!busy)test.disabled=!product.value;
  for(const control of lab.querySelectorAll('input,select,button:not(.lab-group-toggle)'))control.disabled=busy;
  const input=entry.querySelector('textarea');if(input)input.disabled=busy;
  for(const button of [browse,context.querySelector('#lab-open')])button.disabled=busy;
  context.querySelector('#lab-project-save').disabled=busy||!loadedTest||product.value!==loadedProduct||test.value!==loadedTest;
  const point=Number(state?.fields?.['recipe.scanPoint']||0),line=state?.currentLine;
  if(!point){lastPoint=0;lastLine=-1;return;}
  if(point===lastPoint&&line===lastLine)return;
  if(current?.line!==line){
   openScan(line);
   for(const control of lab.querySelectorAll('input,select,button:not(.lab-group-toggle)'))control.disabled=busy;
   const paste=entry.querySelector('textarea');if(paste)paste.disabled=busy;
  }
  if(point!==lastPoint||line!==lastLine){
   result.querySelector('.lab-running-point')?.classList.remove('lab-running-point');
   const target=result.querySelector('tbody')?.rows[point-1];
   target?.classList.add('lab-running-point');target?.scrollIntoView({block:'nearest',inline:'nearest'});
  }
  lastPoint=point;lastLine=line;
 });
 for(const button of recipe.querySelectorAll('button'))if(['加粗','斜体'].includes(button.textContent.trim()))button.classList.add('lab-hide-format');
 place();
})();
