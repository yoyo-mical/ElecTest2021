'use strict';
(()=>{
const panel=document.querySelector('#patterns');
const library=document.querySelector('#pattern-grid');
const categories=panel.querySelector('.pattern-categories');
categories.previousElementSibling?.querySelector('#pattern-count')?.parentElement.setAttribute('hidden','');
const names=['纯色','串扰','条块与渐变','棋盘格','Flicker','线条与对位','组合图案'];
const groups=[...new Set(fpgaRows.map(row=>row.group))];
const controls=document.createElement('section');
controls.id='fpga-controls';
controls.innerHTML='<div class="fpga-library-heading"><b>PATTERN LIBRARY</b><small></small></div><div class="row"><select aria-label="图案分类"></select><input type="search" placeholder="搜索名称或 HEX 编号" aria-label="搜索图案"></div>';
categories.replaceWith(controls);
const layout=document.createElement('div');layout.className='fpga-layout';
const catalog=document.createElement('div');catalog.className='fpga-catalog';
controls.before(layout);layout.append(catalog);catalog.append(controls,library);
const select=controls.querySelector('select'),search=controls.querySelector('input');
const tabs=document.createElement('div');tabs.className='fpga-tabs';controls.append(tabs);
['常用',...names.slice(0,5),'重载',...names.slice(5),'BMP','全部'].forEach(name=>{
 select.add(new Option(name));const tab=document.createElement('button');tab.type='button';tab.textContent=name;
 if(['板载图片','旧版兼容'].includes(name))tab.className='fpga-extra';
 tab.onclick=()=>{select.value=name;render();};tabs.append(tab);
});select.hidden=true;
const quickCategories=new Set(['常用','棋盘格','Flicker','重载','组合图案']);
for(const tab of tabs.children)if(!quickCategories.has(tab.textContent))tab.classList.add('fpga-secondary-tab');
const more=panel.querySelector('[data-workspace-more="patterns"]');
function syncCategories(){tabs.classList.toggle('show-all',panel.classList.contains('workspace-details-open'));}
if(more)new MutationObserver(syncCategories).observe(panel,{attributes:true,attributeFilter:['class']});
syncCategories();
const details=document.createElement('section');
details.id='fpga-details';
const adjustment=document.createElement('details');adjustment.open=true;adjustment.className='fpga-adjustment';
const summary=document.createElement('summary');summary.textContent='参数调整';adjustment.append(summary,details);
const splitter=document.createElement('div');
splitter.className='fpga-splitter';
splitter.tabIndex=0;
splitter.setAttribute('role','separator');
splitter.setAttribute('aria-orientation','vertical');
splitter.setAttribute('aria-label','调整图案库宽度');
catalog.after(splitter);
function resizeCatalog(width){
 const total=layout.clientWidth-12;
 const min=Math.min(260,total*.35),max=Math.max(min,total-320);
 const size=Math.min(max,Math.max(min,width));
 layout.style.setProperty('--fpga-catalog-width',size/total*100+'%');
 splitter.setAttribute('aria-valuenow',String(Math.round(size/total*100)));
}
splitter.onpointerdown=event=>{
 if(event.button!==0)return;
 event.preventDefault();
 splitter.setPointerCapture(event.pointerId);
};
splitter.onpointermove=event=>{
 if(splitter.hasPointerCapture(event.pointerId))resizeCatalog(event.clientX-layout.getBoundingClientRect().left);
};
splitter.onkeydown=event=>{
 if(!['ArrowLeft','ArrowRight'].includes(event.key))return;
 event.preventDefault();
 resizeCatalog(catalog.clientWidth+(event.key==='ArrowLeft'?-20:20));
};
function arrange(){
 if(panel.classList.contains('expanded'))layout.append(adjustment);
 else layout.prepend(adjustment);
}
new MutationObserver(arrange).observe(panel,{attributes:true,attributeFilter:['class']});arrange();
for(const id of ["red","gray","back"])panel.querySelector("#"+id)?.closest("fieldset")?.setAttribute("hidden","");
const legacy=[...library.children];
const originalActions=legacy.map(card=>card.onclick);
const shortNames={red:'红',green:'绿',blue:'蓝',gray128:'灰'};
const labels={
 '00':['红 R','绿 G','蓝 B'],'20':['偶数行灰阶'],'45':['奇数行灰阶','偶数行灰阶'],
 '68':['红 R','绿 G','蓝 B'],'69':['红 R','绿 G','蓝 B'],'7E':['上段灰阶','中段灰阶','下段灰阶'],
 '6F':['首格灰阶','横向格数','纵向格数'],'5D':['左上角灰阶'],'6D':['白边宽度（行）','横向格数','纵向格数'],
 '5E':['背景灰阶',null],'5F':['背景灰阶',null],'60':['背景灰阶',null],
 'A2':['背景灰阶',null,null],'7F':['红段亮度','绿段亮度','蓝段亮度'],
 '90':['第一灰阶','第二灰阶'],'1E':['中间区域灰阶'],'1F':[null],
 '80':['红 R','绿 G','蓝 B'],'85':['红 R','绿 G','蓝 B'],
 '26':['起始灰阶','阶数',null],'28':['起始灰阶','阶数',null],
 '3A':['红 R','绿 G','蓝 B'],'3C':['红 R','绿 G','蓝 B'],'39':['红 R','绿 G','蓝 B'],'3B':['红 R','绿 G','蓝 B'],
 '8F':['中心点 R','中心点 G','中心点 B'],'91':['线条灰阶','背景灰阶',null],
 'A4':['白框灰阶','左右白框宽度','上下白框宽度'],'A1':['背景灰阶','左右边距','上下边距'],
 'A0':['离边界位置','水平参数','垂直参数']
};
for(const code of ['01','02','03','04','05','06','07','08','09','0A','0B','0C','58','59','4A','50','53','5B'])labels[code]=['背景灰阶'];
for(const code of ['15','16','17','18','19','1A','1B','1C','4B','4C','9C','9F','A7'])labels[code]=['图案灰阶'];
for(const code of ['64','65','66','67'])labels[code]=['外围图案灰阶','中心窗灰阶'];
const hex=n=>n.toString(16).toUpperCase().padStart(2,'0');
let selected=null,selectedCard=null;
addEventListener('native-state',()=>{if(selectedCard?.isConnected){for(const card of library.children)card.classList.toggle('active',card===selectedCard);}});
function show(row){
 selected=row;details.replaceChildren();
 const title=document.createElement('strong');title.textContent=({'01':'三分之一黑框','07':'三分之一白框'})[row.code]||row.name;details.append(title);summary.textContent='参数调整 · '+title.textContent;
 const preview=document.createElement('figure');preview.className='fpga-annotated';details.append(preview);
 if(['01','07'].includes(row.code)){
  const drawing=document.createElement('div');drawing.className='fpga-window';drawing.style.setProperty('--window',row.code==='01'?'#000':'#fff');
  drawing.innerHTML='<span class="fpga-window-center"></span><span class="fpga-bg-label">↙ 背景灰阶</span><span class="fpga-fixed-label">中心窗 · 固定</span>';preview.append(drawing);
 }else if(row.code==='00'){const swatch=document.createElement('div');swatch.className='fpga-solid';preview.append(swatch);}else if(row.image){const img=new Image();img.src=row.image;img.alt=row.name;preview.append(img);}else if(row.swatch){const swatch=document.createElement('div');swatch.className='fpga-solid';swatch.style.background=row.swatch;preview.append(swatch);}
 const note=document.createElement('small');note.textContent=row.note||'';note.hidden=!row.note;details.append(note);
 const frame=row.frame.replace(/\s+/g,' ').toUpperCase();
 const tokens=frame.split(' ');
 const valid=/^AA 02(?: [A-F0-9]{2})+ 0F 00 12 48$/.test(frame)&&tokens[3]===row.code&&(tokens.length-8)%2===0;
 const pending=row.yellow||!valid||['25','27','A3','1F','5A','A5','3E','42','C9','CA'].includes(row.code);
 const form=document.createElement('div');form.className='fpga-params';details.append(form);
 const out=document.createElement('code');details.append(out);
 const status=document.createElement('small');details.append(status);
 const params=valid?tokens.slice(4,-4).filter((_,i)=>i%2===1).map(v=>parseInt(v,16)):[];
 const controls=[];
 const solid=row.code==='00';
 const channels={12:[0],13:[1],14:[2]};
 if(solid&&params.length===3){
  const active=channels[row.row]||[0,1,2];
  number('灰阶',params[active[0]],255,(b,v)=>{for(let i=0;i<3;i++)b[i]=active.includes(i)?v:0;});
 }
 function number(label,value,max,apply){
  const el=document.createElement('label');el.textContent=label;
  const input=document.createElement('input');input.type='number';input.min=0;input.max=max;input.step=1;input.value=value;
  input.oninput=update;input.onfocus=()=>preview.classList.add('parameter-focused');input.onblur=()=>preview.classList.remove('parameter-focused');el.append(input);form.append(el);controls.push({input,apply,max});
 }
 function update(){
  const bytes=[...params];
  for(const {input,apply,max} of controls){const v=input.valueAsNumber;if(!Number.isInteger(v)||v<0||v>max){out.textContent='参数超出范围';return;}apply(bytes,v);}
  preview.style.setProperty("--gray", "rgb("+bytes[0]+","+bytes[0]+","+bytes[0]+")");
  if(solid)preview.style.setProperty("--solid","rgb("+bytes.join(",")+")");
  out.textContent=valid?['AA','02',...tokens.slice(2,-4).map((v,i)=>i>=2&&i%2?hex(bytes[(i-3)/2]):v),'0F','00','12','48'].join(' '):row.frame||'资料未提供可用示例帧';
 }
 if(!pending){
  if(['6B','6C','81','84','A6','A8'].includes(row.code)&&params.length===3){
   const window=['6B','6C'].includes(row.code),mask=window?15:['81','84'].includes(row.code)?3:255;
   number('背景灰阶',params[0],255,(b,v)=>b[0]=v);
   if(window){const label=document.createElement('label');label.textContent='窗口颜色';const color=document.createElement('select');color.add(new Option('黑色','0'));color.add(new Option('白色','128'));color.value=String(params[1]&128);color.onchange=()=>{params[1]=(params[1]&127)|Number(color.value);update();};label.append(color);form.append(label);}
   number(window?(row.code==='6B'?'窗口垂直起点':'窗口水平起点'):row.code==='A6'?'行分界':row.code==='A8'?'列分界':row.code==='81'?'红框边长':'红框宽度',((params[1]&mask)<<8)|params[2],(mask<<8)|255,(b,v)=>{b[1]=(b[1]&~mask)|(v>>8);b[2]=v&255;});
  }else if(['51','73','4F'].includes(row.code)&&params.length===3){
   number('背景灰阶',params[0],255,(b,v)=>b[0]=v);
   for(const [label,index,shift] of [['上边线颜色',1,4],['下边线颜色',1,0],['左边线颜色',2,4],['右边线颜色',2,0]]){
    number(label+'（0–7）',(params[index]>>shift)&7,7,(b,v)=>b[index]=(b[index]&~(7<<shift))|(v<<shift));
   }
  }else if(!solid){
   const channel={103:0,104:1,105:2,108:0,109:1,110:2,113:0,118:0,119:1,120:2}[row.row];
   params.forEach((v,i)=>{
    const label=labels[row.code]?.[i];
    if(channel!==undefined){if(i===channel)number('灰阶',v,255,(b,n)=>b[i]=n);}
    else if(label)number(label,v,255,(b,n)=>b[i]=n);
   });
  }
 }
 const unverified=params.length>0&&!solid&&!['6B','6C','81','84','A6','A8','51','73','4F'].includes(row.code)&&params.length>(labels[row.code]?.length||0);
 if(unverified){form.replaceChildren();controls.length=0;}
 status.textContent=pending||unverified?'待确认 · 查看资料示例':controls.length?'':'固定画面';
 const button=document.createElement('button');
 button.type='button';button.textContent='应用到设备';
 const allowedCustom=valid&&!pending&&!unverified&&['00','01','07','20'].includes(row.code);
 const canApply=allowedCustom||!!row.original;
 button.disabled=!canApply;
 if(!canApply)status.textContent='仅预览 · 指令待实机确认';
 button.onclick=safe(async()=>{
  if(!controls.every(({input})=>input.value!==''&&input.validity.valid))return;
  const edited=controls.length>0&&out.textContent!==frame;
  if(row.original&&!edited){await row.original();return;}
  if(!allowedCustom){status.textContent='调整值仅供预览。请重新选择图案以应用原预设。';return;}
  const reply=await native('serial.send',{fields:{'serial.send':out.textContent,'serial.sendMode':'HEX','serial.ending':'none'}});
  applyState(reply.state,true);
  status.textContent='已发送';
 });
 details.append(button);
 update();
}
function render(){
 for(const tab of tabs.querySelectorAll('button:not(.fpga-more-tabs)'))tab.setAttribute('aria-pressed',String(tab.textContent===select.value));
 library.replaceChildren();
 const q=search.value.trim().toLowerCase().replace(/^0x/,'');
 if(select.value==='常用'){
  controls.querySelector('small').textContent=legacy.length+' 个图案';
  legacy.forEach((card,i)=>{
   const def=patternDefinitions[i];
   const tag=String(def[3]).split(',').filter(Boolean);
   const code=tag[1]||'';
   const name=({'1/3黑框':'Crosstalk 1/3 黑框','1/3白框':'Crosstalk 1/3 白框'})[def[0]]||def[0];
   card.lastElementChild.textContent=name;
   card.onclick=()=>{
    selectedCard=card;
    for(const other of legacy)other.classList.toggle('active',other===card);
    const frame=/^[0-3]$/.test(tag[0])?'AA 02 '+tag.slice(1).map(v=>'00 '+v).join(' ')+' 0F 00 12 48':'';
    show({name,code,frame,note:'',swatch:def[2],original:/^[0-3]$/.test(tag[0])?originalActions[i]:null,row:({'pictureBox5':12,'pictureBox6':13,'pictureBox7':14,'preset.r100':12,'preset.g100':13,'preset.b100':14})[def[4]]});
   };
   library.append(card);
  });
  legacy[0]?.click();return;
 }
 if(select.value==='重载'){controls.querySelector('small').textContent='0 个图案';details.textContent='图案归类待确认';summary.textContent='参数调整';return;}
 if(select.value==='旧版兼容'){library.append(...legacy.filter(card=>card.textContent.toLowerCase().includes(q)));return;}
 if(select.value==='BMP'){
  details.replaceChildren();const label=document.createElement('label');label.textContent='板载图片序号（从 0 开始）';
  const input=document.createElement('input');input.type='number';input.min=0;input.max=65535;input.value=0;
  const frame=document.createElement('code');const update=()=>{const n=input.valueAsNumber;frame.textContent=Number.isInteger(n)&&n>=0&&n<=65535?'AA 10 '+hex(n>>8)+' '+hex(n&255)+' 0F 00 12 48':'序号超出范围';};input.oninput=update;label.append(input);details.append(label,frame);update();controls.querySelector('small').textContent='板载图片 · AA10';return;
 }
 const rows=fpgaRows.filter(row=>(select.value==='常用'?[12,13,14,15,16,17,20,21,76,77,102].includes(row.row):select.value==='全部'||groups[names.indexOf(select.value)]===row.group)&&(!q||(row.code+' '+row.name).toLowerCase().includes(q)));
 controls.querySelector('small').textContent=rows.length+' 个图案';
 for(const row of rows){
  const card=document.createElement('button');card.className='pattern-card';card.classList.toggle('active',row===(rows.includes(selected)?selected:rows[0]));
  if(row.image){const img=new Image();img.loading='lazy';img.src=row.image;img.alt='';card.append(img);}
  const label=document.createElement('span');label.textContent=shortNames[row.name]||({'01':'Crosstalk 1/3 黑框','07':'Crosstalk 1/3 白框','20':'1×1 Bar','45':'1×1 Bar（双灰阶）'})[row.code]||row.name;card.append(label);card.onclick=()=>{selectedCard=card;library.querySelector('.active')?.classList.remove('active');card.classList.add('active');show(row);};library.append(card);
 }
 if(rows.length)show(rows.includes(selected)?selected:rows[0]);else details.textContent='没有匹配的图案';
}
select.onchange=render;search.oninput=render;
const expand=panel.querySelector('[data-expand]');

render();
})();
