'use strict';
// Native-only UI adaptation. No preview data generators or simulated operations are shipped.
(() => {
 const uart=$('#uart>.body'),log=$('#serial-log'),heading=log.previousElementSibling,receive=document.createElement('section');receive.className='serial-receive';heading.before(receive);receive.append(heading);
 const toolbar=document.createElement('div');toolbar.className='serial-receive-toolbar';toolbar.innerHTML='<div class="serial-view-modes" role="group" aria-label="接收显示格式"><button id="rx-hex" aria-pressed="false">HEX</button><button id="rx-ascii" aria-pressed="true">ASCII</button></div><span class="spacer"></span><button id="rx-copy">复制</button>';toolbar.append($('[data-action=clear-log]'));receive.append(toolbar,log);
 const stats=document.createElement('p');stats.id='rx-stats';stats.className='serial-console-info';receive.append(stats,$('#serial-ascii'));
 const send=document.createElement('section');send.className='serial-manual-send';receive.after(send);send.innerHTML='<p class="section-label">SEND / 手动发送</p>';
 const modes=uart.querySelector('.radio-row'),row=uart.querySelector('.send-row');send.append(modes,row);modes.querySelector('input[value="字符串"]').parentElement.lastChild.textContent='文本（ASCII）';modes.querySelector('input[value=HEX]').checked=true;
 const ending=document.createElement('label');ending.className='serial-ending';ending.innerHTML='<span>文本结尾</span><select id="send-ending"><option value="none">不追加</option><option value="cr">CR · 回车</option><option value="lf">LF · 换行</option><option value="crlf">CRLF · 回车换行</option></select>';send.append(ending);
 const sendStatus=document.createElement('p');sendStatus.id='serial-send-status';sendStatus.className='serial-console-info';sendStatus.textContent='发送格式独立于接收显示；HEX 不追加结尾。';send.append(sendStatus);
 let rxMode='ASCII',lastRx=null;
 function sendMode(){return modes.querySelector('input:checked').value==='HEX'?'HEX':'ASCII';}
 for(const radio of modes.querySelectorAll('input'))radio.onchange=()=>{ending.querySelector('select').disabled=!!state?.busy||sendMode()==='HEX';};
 row.querySelector('button').onclick=safe(async()=>{const fields={'serial.send':$('#send-data').value,'serial.sendMode':sendMode(),'serial.ending':$('#send-ending').value};const reply=await native('serial.send',{fields});applyState(reply.state);sendStatus.textContent='串口写入已完成（'+sendMode()+'）。';});
 let copyText='';
 function renderRx(){const raw=state?.serialRxHex||'';const key=rxMode+'|'+raw+'|'+state?.serialRxDropped;if(key===lastRx)return;lastRx=key;const bytes=raw?raw.split(/\s+/).filter(Boolean).map(x=>parseInt(x,16)):[];copyText=rxMode==='HEX'?raw:bytes.map(v=>v===9||v===10||v===13||v>=32&&v<=126?String.fromCharCode(v):'\\x'+v.toString(16).toUpperCase().padStart(2,'0')).join('');log.textContent=copyText||'等待串口数据…';log.dataset.format=rxMode;stats.textContent='接收 '+(state?.serialRxTotal||0)+' 字节 · '+rxMode+' 显示'+(state?.serialRxDropped?' · 查看区仅保留最近 64 KiB':'');for(const mode of ['HEX','ASCII'])$('#rx-'+mode.toLowerCase()).setAttribute('aria-pressed',String(rxMode===mode));$('#rx-copy').disabled=!bytes.length;}
 $('#rx-hex').onclick=()=>{rxMode='HEX';renderRx();};$('#rx-ascii').onclick=()=>{rxMode='ASCII';renderRx();};$('#rx-copy').onclick=safe(()=>native('clipboard.copy',{text:copyText}));
 $('#ascii-from-log').onclick=()=>{$('#ascii-source').value=state?.serialRxHex||'';$('#ascii-source').dispatchEvent(new Event('input',{bubbles:true}));};
 // Keep operations in their owning panels.
 const recipe=$('#recipe'),bar=$('.commandbar'),edit=recipe.querySelector('.recipe-toolbar'),run=document.createElement('div');run.className='recipe-run-controls';
 const head=$('#run-head'),current=$('#run-current'),pause=bar.querySelector('[data-action=pause]'),stepButton=bar.querySelector('[data-action=step]'),summary=bar.querySelector('.summary');head.classList.add('primary');head.dataset.action='run';pause.lastChild.textContent='暂停';pause.title='在当前指令或采样步骤完成后的安全边界暂停';
 const resume=document.createElement('button');resume.id='native-resume';resume.textContent='继续';resume.onclick=safe(()=>command('resume'));
 const stop=document.createElement('button');stop.id='native-stop';stop.textContent='停止';stop.onclick=safe(()=>command('stop'));
 run.append(head,current,pause,resume,stop,stepButton);const area=document.createElement('div');area.className='recipe-command-area';edit.before(area);area.append(edit,run);edit.classList.add('recipe-edit-toolbar');recipe.querySelector('.panel-actions').prepend(summary);bar.remove();
 edit.querySelector('[data-action=import]').lastChild.textContent='导入配方';edit.querySelector('[data-action=export-recipe]').lastChild.textContent='导出配方';
 $('#code [data-action=download]').lastChild.textContent='下发脚本';const target=document.createElement('span');target.id='arm-send-target';$('#code .code-footer').insertBefore(target,$('#line-count'));
 const exit=document.createElement('button');exit.id='app-exit';exit.textContent='退出';exit.onclick=safe(()=>native('exit'));$('.top-right').append(exit);
 // Result views share real native samples and the original paired-column result table.
 const chart=$('#chart'),tabs=chart.querySelector('.chart-tabs'),currentTab=chart.querySelector('[data-chart-view=current]'),galleryTab=chart.querySelector('[data-chart-view=compare]');galleryTab.disabled=false;galleryTab.textContent='Chart2 · 多图';galleryTab.dataset.chartView='gallery';galleryTab.title='各次真实测试独立显示';
 function tab(id,text){const button=document.createElement('button');button.id=id;button.textContent=text;button.setAttribute('role','tab');button.setAttribute('aria-selected','false');tabs.querySelector('.chart-tab-spacer').before(button);return button;}
 const sheetTab=tab('measurement-sheet-tab','Sheet · 当前组'),bothTab=tab('chart-combined-tab','曲线 + Sheet'),allTab=tab('measurement-all-tab','全部测量组');
 const workspace=document.createElement('div');workspace.id='chart-current-workspace';const graph=chart.querySelector('.chart-body');graph.before(workspace);workspace.append(graph);
 const sheet=document.createElement('div');sheet.id='measurement-sheet';sheet.className='chart-measure-sheet';sheet.hidden=true;sheet.innerHTML='<div class="measurement-toolbar"><span id="measurement-summary"></span><button id="measurement-export">导出当前曲线 CSV</button><button id="measurement-open-original">全部测量组</button></div><div class="measurement-scroll"><table id="measurement-table"><thead></thead><tbody></tbody></table><p id="measurement-empty">等待实测数据</p></div><p class="measurement-note">与当前曲线共用原始采样点，不包含插值点。</p>';workspace.append(sheet);
 const all=document.createElement('div');all.id='measurement-all-view';all.className='chart-measure-sheet';all.hidden=true;all.innerHTML='<div class="measurement-toolbar"><span>全部测量组 · 参数码值 / 测量值</span><button id="sheet-export-all">导出全部测量组 CSV</button><button id="sheet-clear-records">清空记录</button></div><div class="measurement-scroll"></div><p id="native-sheet-empty" class="measurement-note">暂无测量记录。</p>';all.querySelector('.measurement-scroll').append($('#native-sheet'));chart.append(all);
 $('#measurement-export').onclick=safe(()=>command('chart.export'));$('#sheet-export-all').onclick=safe(()=>command('sheet.export'));$('#sheet-clear-records').onclick=safe(()=>command('sheet.clear'));
 const gallery=document.createElement('div');gallery.id='chart-gallery';gallery.className='chart-gallery';gallery.hidden=true;gallery.innerHTML='<div class="measurement-toolbar"><span id="chart-gallery-summary"></span><button id="chart-gallery-export">导出全部测量组 CSV</button></div><div id="chart-gallery-grid" class="chart-gallery-grid"></div><p class="measurement-note">每组使用真实原始点及独立坐标、单位；不叠加不同测试参数。</p>';chart.append(gallery);$('#chart-gallery-export').onclick=safe(()=>command('sheet.export'));
 let mode='curve',drawQueued=false;const plots=new Map();const groups=()=>state?.authorized?(state.groups??[]).filter(g=>g.points.length):[];
 function setMode(next,expand=true){if(expand&&['both','gallery'].includes(next)&&!chart.classList.contains('expanded'))chart.querySelector('[data-expand]').click();mode=next;chart.dataset.view=next;workspace.dataset.mode=next;workspace.hidden=['all','gallery'].includes(next);graph.hidden=!['curve','both'].includes(next);sheet.hidden=!['sheet','both'].includes(next);all.hidden=next!=='all';gallery.hidden=next!=='gallery';for(const [button,value]of [[currentTab,'curve'],[sheetTab,'sheet'],[bothTab,'both'],[allTab,'all'],[galleryTab,'gallery']]){button.classList.toggle('active',value===next);button.setAttribute('aria-selected',String(value===next));}if(next==='gallery')renderGallery();requestAnimationFrame(()=>{renderChart();queueDraw();});}
 currentTab.onclick=()=>setMode('curve');sheetTab.onclick=()=>setMode('sheet');bothTab.onclick=()=>setMode('both');allTab.onclick=()=>setMode('all');galleryTab.onclick=()=>setMode('gallery');$('#measurement-open-original').onclick=()=>setMode('all');
 new MutationObserver(()=>{if(!chart.classList.contains('expanded')&&['both','gallery'].includes(mode))setMode('curve',false);}).observe(chart,{attributes:true,attributeFilter:['class']});
 function renderCurrent(){const points=state?.authorized?(state.points??[]):[],table=$('#measurement-table');table.tHead.replaceChildren();table.tBodies[0]?.remove();const header=table.createTHead().insertRow();for(const value of ['#','参数 / 原标签',(state?.metric||'测量值')+' / '+(state?.unit||'')]){const th=document.createElement('th');th.textContent=value;header.append(th);}const body=table.createTBody();points.forEach((p,i)=>{const row=body.insertRow();row.dataset.pointIndex=i;row.tabIndex=0;for(const value of [i+1,p.x,p.y])row.insertCell().textContent=String(value);row.onclick=()=>{selectedPoint=i;renderChart();highlight();$('#chart-reading').textContent=p.x+' · '+p.y+' '+state.unit;$('#chart-reading').classList.add('pinned');};row.onkeydown=e=>{if(e.key==='Enter')row.click();};});$('#measurement-summary').textContent=(state?.test||'当前测试')+' · '+points.length+' 个原始点';$('#measurement-empty').hidden=!!points.length;highlight();}
 function highlight(){for(const row of $$('#measurement-table tbody tr'))row.classList.toggle('selected',Number(row.dataset.pointIndex)===selectedPoint);}
 function element(tag,cls,text){const e=document.createElement(tag);if(cls)e.className=cls;if(text!==undefined)e.textContent=String(text);return e;}
 function renderGallery(){
  const records=groups(),grid=document.getElementById('chart-gallery-grid');grid.replaceChildren();plots.clear();document.getElementById('chart-gallery-summary').textContent=records.length+' 组结果 · 独立坐标 / 单位';document.getElementById('chart-gallery-export').disabled=!records.length;
  if(!records.length){grid.append(element('p','gallery-empty','暂无已记录的测试结果。采样后在这里逐组显示。'));return;}
  for(const group of records){const card=element('section','result-chart-card');card.dataset.runId=group.runId;card.dataset.testKey=group.testKey;const header=element('div','result-chart-header');header.append(element('h3','',group.title),element('span','result-group-id','第 '+group.runId+' 组'));const meta=element('div','result-chart-meta');meta.append(element('span','',group.metric+' / '+group.unit),element('span','',group.points.length+' 个原始点'));const plot=element('div','result-chart-plot');card.append(header,meta,plot);grid.append(card);plots.set(plot,group);}
  queueDraw();
 }
 function svg(tag,attrs={},text){const e=document.createElementNS('http://www.w3.org/2000/svg',tag);for(const [k,v]of Object.entries(attrs))e.setAttribute(k,String(v));if(text!==undefined)e.textContent=String(text);return e;}
 function draw(plot,g){
  const w=Math.max(280,plot.clientWidth),h=Math.max(140,plot.clientHeight);const s=svg('svg',{viewBox:`0 0 ${w} ${h}`,role:'img','aria-label':g.title+'，'+g.metric+'，单位'+g.unit});const b={l:49,r:w-14,t:14,b:h-42};const ys=g.points.map(p=>p.y);let lo=Math.min(...ys),hi=Math.max(...ys),pad=(hi-lo)*.12||1;lo-=pad;hi+=pad;if(g.metric==='Lv'&&Math.min(...ys)>=0)lo=Math.max(0,lo);const X=i=>g.points.length===1?(b.l+b.r)/2:b.l+i*(b.r-b.l)/(g.points.length-1),Y=y=>b.b-(y-lo)*(b.b-b.t)/(hi-lo);
  for(let i=0;i<=3;i++){const y=b.t+i*(b.b-b.t)/3;s.append(svg('line',{x1:b.l,x2:b.r,y1:y,y2:y,stroke:'var(--chart-grid)'}),svg('text',{x:b.l-7,y:y+4,'text-anchor':'end',fill:'var(--theme-muted)','font-size':10},(hi-i*(hi-lo)/3).toFixed(g.decimals)));}
  const ticks=Math.min(4,g.points.length);for(let i=0;i<ticks;i++){const j=ticks===1?0:Math.round(i*(g.points.length-1)/(ticks-1));s.append(svg('text',{x:X(j),y:b.b+17,'text-anchor':'middle',fill:'var(--theme-muted)','font-size':10},(g.hex?'0x':'')+g.points[j].x));}
  if(g.points.length>1)s.append(svg('polyline',{points:g.points.map((p,i)=>X(i)+','+Y(p.y)).join(' '),fill:'none',stroke:'var(--chart-line)','stroke-width':1.8}));
  g.points.forEach((p,i)=>{const c=svg('circle',{cx:X(i),cy:Y(p.y),r:i===g.points.length-1?3.5:2.8,fill:i===g.points.length-1?'var(--chart-line)':'var(--theme-surface)',stroke:'var(--chart-line)','stroke-width':1.3});c.append(svg('title',{},p.x+' · '+p.y.toFixed(g.decimals)+' '+g.unit));s.append(c);});s.append(svg('text',{x:(b.l+b.r)/2,y:h-5,'text-anchor':'middle',fill:'var(--theme-muted)','font-size':10},g.axisX));plot.replaceChildren(s);
 }
 function queueDraw(){if(drawQueued)return;drawQueued=true;requestAnimationFrame(()=>{drawQueued=false;if(mode==='gallery')for(const [plot,g]of plots)draw(plot,g);});}

 new ResizeObserver(queueDraw).observe($('#chart-gallery-grid'));
 function render(){
  renderRx();renderCurrent();if(mode==='gallery')renderGallery();
  const busy=!!state?.busy,authorized=!!state?.authorized;
  for(const button of $$('[data-action],#run-head,#run-current,#recipe-format,#choose-control-file,#bold-recipe,#italic-recipe,.pattern-card'))button.disabled=!authorized||busy&&!['pause','reset','goto'].includes(button.dataset.action);
  pause.disabled=!state?.runningRecipe||!!state?.pauseRequested;resume.disabled=!state?.pauseRequested;stop.disabled=!busy;
  for(const button of [$('#measurement-export'),$('#sheet-export-all'),$('#sheet-clear-records'),$('#chart-gallery-export')])button.disabled=!authorized||busy;
  for(const input of $$('input[name=encoding],input[name=mode]'))input.disabled=busy;
  $('#send-ending').disabled=busy||sendMode()==='HEX';
  for(const [id,key]of [['apply-rgb','red'],['apply-gray','gray'],['apply-back','back']])$('#'+id).disabled=!authorized||busy||state?.enabled?.['pattern.'+key]===false;
  $('#ca-connect').classList.toggle('is-connected',!!state?.meterConnected);$('#ca-connect').setAttribute('aria-pressed',String(!!state?.meterConnected));
  target.textContent=state?.serialConnected?'目标：'+state.fields['serial.port']:'目标：串口未连接';
  $('#native-sheet-empty').hidden=!!state?.sheet?.length;
 }
 addEventListener('native-state',render);addEventListener('native-point',highlight);render();setMode('curve',false);
})();
