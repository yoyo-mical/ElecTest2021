'use strict';
// Shared layout tools use real native state and fixed C# operations, never demo producers.
(() => {
 const rgb=document.createElement('div');rgb.className='pattern-color-groups';
 function group(label,names,buttonId,cls){const fs=document.createElement('fieldset');fs.className='pattern-value-group';const title=document.createElement('legend');title.textContent=label;fs.append(title);const row=document.createElement('div');row.className=cls;for(const name of names)row.append(document.getElementById(name).closest('.field'));const button=document.getElementById(buttonId);button.textContent='应用';row.append(button);fs.append(row);return fs;}
 const old=document.getElementById('red').closest('.rgb');old.before(rgb);
 rgb.append(group('RGB',['red','green','blue'],'apply-rgb','pattern-rgb-fields'),group('Gray · 灰阶',['gray'],'apply-gray','pattern-gray-fields'));
 if(!old.children.length)old.remove();
 document.getElementById('back').closest('label').after(document.getElementById('apply-back'));
 const status=document.createElement('p');status.id='pattern-apply-status';status.setAttribute('role','status');status.textContent='RGB 与 Gray 独立保存；点击对应应用按钮发送。';rgb.append(status);
 document.querySelector('.pattern-apply').remove();
 for(const [id,mode] of [['apply-rgb','rgb'],['apply-gray','gray']])document.getElementById(id).onclick=safe(async()=>{
  const ids=mode==='rgb'?['red','green','blue']:['gray'];const values=ids.map(id=>{const raw=document.getElementById(id).value;const n=Number(raw);if(!raw.trim()||!Number.isInteger(n)||n<0||n>255)throw Error('请输入 0–255 的整数。');return n;});
  await command('pattern.'+mode);status.textContent=(mode==='rgb'?'RGB：'+values.join(' / '):'Gray：'+values[0]+' → '+[values[0],values[0],values[0]].join(' / '))+'，原 C# 发送流程已返回。';
 });
})();
