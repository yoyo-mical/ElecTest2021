'use strict';
(() => {
  const example = '52 65 61 64 20 53 6C 61 76 65 20 49 43 2D 50 61 67 65 5B 31 30 48 5D 20 52 45 47 5B 30 38 48 5D 20 3D 20 30 78 31 38 0D 0A';
  function decode(input) {
    if (input.length > 100000) throw Error('输入过长，请分段转换（最多 100000 个字符）。');
    const text = input.trim();
    if (!text) return {text:'', bytes:[], crlf:0, cr:0, lf:0, escaped:0};
    const bytes = [];
    for (let token of text.split(/[\s,;]+/)) {
      if (!token) continue;
      if (/^0x/i.test(token)) {
        if (!/^0x[0-9a-f]{2}$/i.test(token)) throw Error('0x 前缀后应为两位十六进制，例如 0x52。');
        token = token.slice(2);
      }
      if (!/^[0-9a-f]+$/i.test(token)) throw Error('只接受十六进制字节，例如 52 65 或 5265；请去掉日志标题、时间戳等文字。');
      if (token.length % 2) throw Error('每个字节需要两位十六进制，请检查落单的数字。');
      for (let i=0; i<token.length; i+=2) bytes.push(parseInt(token.slice(i,i+2),16));
    }
    let result='', crlf=0, cr=0, lf=0, escaped=0;
    bytes.forEach((byte,i) => {
      if (byte===13) { cr++; if (bytes[i+1]===10) crlf++; }
      if (byte===10) lf++;
      if (byte===9 || byte===10 || byte===13 || (byte>=32 && byte<=126)) result+=String.fromCharCode(byte);
      else { result+='\\x'+byte.toString(16).toUpperCase().padStart(2,'0'); escaped++; }
    });
    return {text:result,bytes,crlf,cr,lf,escaped};
  }
  // Pure conversion is also used by targeted tests; it has no connection to native operations.
  window.ElecSerialAscii = Object.freeze({decode});
  const log=document.getElementById('serial-log');
  if (!log) return;
  const panel=document.createElement('details');
  panel.className='serial-ascii'; panel.id='serial-ascii';
  panel.innerHTML=`<summary>HEX → ASCII <span>文本转换</span></summary>
    <div class="serial-ascii-content">
      <label for="ascii-source">粘贴接收的 HEX 字节</label>
      <textarea id="ascii-source" class="mono" spellcheck="false" placeholder="52 65 61 64 20 … 0D 0A" maxlength="100000"></textarea>
      <div class="ascii-actions"><button type="button" id="ascii-convert">转换</button><button type="button" id="ascii-from-log">取接收区</button><button type="button" id="ascii-example">使用示例</button><button type="button" id="ascii-clear">清空</button></div>
      <div class="ascii-result-head"><label for="ascii-result">ASCII 结果</label><button type="button" id="ascii-copy" disabled>复制</button></div>
      <textarea id="ascii-result" class="mono" readonly spellcheck="false" placeholder="转换结果显示在这里"></textarea>
      <p id="ascii-info" role="status" aria-live="polite">仅转换文本，不会向串口发送数据。</p>
    </div>`;
  log.after(panel);
  const source=document.getElementById('ascii-source'), output=document.getElementById('ascii-result'), info=document.getElementById('ascii-info'), copy=document.getElementById('ascii-copy');
  let result=null;
  function convert() {
    try {
      result=decode(source.value);output.value=result.text;copy.disabled=!result.bytes.length;
      source.removeAttribute('aria-invalid');info.classList.remove('error');
      if (!result.bytes.length) {info.textContent='仅转换文本，不会向串口发送数据。';return;}
      const bytes=result.bytes;
      let ending='末尾无 CR/LF';
      if (bytes.length>=2 && bytes[bytes.length-2]===13 && bytes[bytes.length-1]===10) ending='末尾 0D 0A = CRLF（回车＋换行）';
      else if (bytes[bytes.length-1]===10) ending='末尾 0A = LF（换行）';
      else if (bytes[bytes.length-1]===13) ending='末尾 0D = CR（回车）';
      info.textContent=bytes.length+' 字节 · '+ending+'。'+(result.cr||result.lf?' CRLF '+result.crlf+' 组，CR '+result.cr+' 个，LF '+result.lf+' 个。':'')+(result.escaped?' '+result.escaped+' 个非可打印 ASCII 字节以 \\xNN 显示，未按 UTF-8 猜测。':'');
    } catch(error) {
      result=null;output.value='';copy.disabled=true;source.setAttribute('aria-invalid','true');info.classList.add('error');info.textContent=error.message;
    }
  }
  source.addEventListener('input',convert);
  document.getElementById('ascii-convert').onclick=convert;
  document.getElementById('ascii-example').onclick=()=>{source.value=example;convert();};
  document.getElementById('ascii-from-log').onclick=()=>{source.value=log.textContent;convert();};
  document.getElementById('ascii-clear').onclick=()=>{source.value='';convert();};
  copy.onclick=async()=>{
    if (!result || !result.bytes.length) return;
    try {
      await navigator.clipboard.writeText(result.text);
      info.textContent='已复制 ASCII 结果（保留原 CR/LF 字符）。';
    } catch {info.textContent='无法访问剪贴板，请选中结果后手动复制。';}
  };
})();
