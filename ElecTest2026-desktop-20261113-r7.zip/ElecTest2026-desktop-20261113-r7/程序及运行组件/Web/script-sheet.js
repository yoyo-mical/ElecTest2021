'use strict';
// A read-only, source-preserving line table. It does not compile or send instructions.
(() => {
 const editor=document.getElementById('editor'),view=document.getElementById('sheet-view'),tab=document.querySelector('[data-code-tab="sheet-view"]');
 tab.title='查看当前脚本的逐行指令表';tab.setAttribute('aria-label','Sheet · 脚本指令表');
 view.replaceChildren();view.innerHTML='<div class="script-sheet-toolbar"><strong>脚本指令表</strong><button type="button" id="script-sheet-locate" disabled>定位到 Code</button></div><p class="script-sheet-note">只读查看，与 Code 同步。双击一行可定位原文。</p><div class="script-sheet-scroll"><table id="script-instruction-table"><thead><tr><th>行号</th><th>类型</th><th>脚本原文</th></tr></thead><tbody></tbody></table><p id="script-sheet-empty" hidden>当前脚本为空。</p></div><p id="script-sheet-summary" class="script-sheet-note" role="status"></p>';
 const table=document.getElementById('script-instruction-table'),locate=document.getElementById('script-sheet-locate');let selected=-1,lastText=null;
 function lines(){return editor.value===''?[]:editor.value.split('\n');}
 function highlight(){for(const row of table.tBodies[0].rows)row.classList.toggle('selected',Number(row.dataset.line)===selected);locate.disabled=selected<0||selected>=lines().length;}
 function render(){const text=editor.value;if(text===lastText){highlight();return;}lastText=text;const source=lines();table.tBodies[0].replaceChildren();let commands=0,comments=0,blank=0;
  source.forEach((raw,i)=>{const kind=!raw.trim()?'空行':raw.trimStart().startsWith('//')?'注释':'指令';if(kind==='空行')blank++;else if(kind==='注释')comments++;else commands++;
   const row=table.tBodies[0].insertRow();row.dataset.line=i;row.dataset.kind=kind;row.tabIndex=0;for(const value of [String(i+1).padStart(2,'0'),kind,raw])row.insertCell().textContent=value;
   row.onclick=()=>{selected=i;highlight();};row.ondblclick=()=>{selected=i;goToCode();};row.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();selected=i;goToCode();}else if(e.key===' '){e.preventDefault();selected=i;highlight();}};
  });
  if(selected>=source.length)selected=-1;highlight();document.getElementById('script-sheet-empty').hidden=source.length>0;document.getElementById('script-sheet-summary').textContent=source.length+' 行 · '+commands+' 条指令 · '+comments+' 行注释 · '+blank+' 行空白';
 }
 function goToCode(){const source=lines();if(selected<0||selected>=source.length)return;const start=source.slice(0,selected).reduce((n,l)=>n+l.length+1,0);document.querySelector('[data-code-tab="code-view"]').click();editor.focus();editor.setSelectionRange(start,start+source[selected].length);editor.scrollTop=Math.max(0,(selected-2)*(parseFloat(getComputedStyle(editor).lineHeight)||22));editor.dispatchEvent(new Event('scroll'));}
 locate.onclick=goToCode;editor.addEventListener('input',render);tab.addEventListener('click',render);
 new MutationObserver(render).observe(document.getElementById('line-count'),{childList:true,subtree:true,characterData:true});
 render();
})();
