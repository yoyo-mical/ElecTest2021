'use strict';
(() => {
  const center = document.querySelector('.column.center');
  const upper = center.querySelector('.upper');
  const code = document.getElementById('code');
  const chart = document.getElementById('chart');
  const recipe = document.getElementById('recipe');
  if (!center || !upper || !code || !chart || !recipe) return;

  function install({id, parent, first, axis, firstVar, secondVar, minimum, otherMinimum, orientation, label}) {
    const handle = document.createElement('div');
    handle.id = id;
    handle.className = 'internal-split ' + (axis === 'x' ? 'vertical' : 'horizontal');
    handle.tabIndex = 0;
    handle.setAttribute('role', 'separator');
    handle.setAttribute('aria-orientation', orientation);
    handle.setAttribute('aria-label', label);
    handle.title = label + '；拖动或用方向键调整，双击恢复比例';
    first.after(handle);
    let active = null;
    const dimension = axis === 'x' ? 'width' : 'height';
    const coord = axis === 'x' ? 'clientX' : 'clientY';
    const size = () => axis === 'x' ? parent.clientWidth : parent.clientHeight;
    const handleSize = () => axis === 'x' ? handle.offsetWidth : handle.offsetHeight;
    function metrics() {
      const factor = parent.getBoundingClientRect()[dimension] / size();
      return {factor, total: size() - handleSize(), current: first.getBoundingClientRect()[dimension] / factor};
    }
    function updateAria() {
      const {total, current} = metrics();
      if (total <= 0) return;
      handle.setAttribute('aria-valuemin', String(Math.round(minimum / total * 100)));
      handle.setAttribute('aria-valuemax', String(Math.round((total - otherMinimum) / total * 100)));
      handle.setAttribute('aria-valuenow', String(Math.round(current / total * 100)));
      handle.setAttribute('aria-valuetext', Math.round(current) + ' 像素');
    }
    function change(value) {
      const {total} = metrics();
      if (total < minimum + otherMinimum) return;
      const firstSize = Math.max(minimum, Math.min(total - otherMinimum, value));
      parent.style.setProperty(firstVar, (firstSize / total) + 'fr');
      parent.style.setProperty(secondVar, (1 - firstSize / total) + 'fr');
      updateAria();
    }
    function reset() {
      parent.style.removeProperty(firstVar);
      parent.style.removeProperty(secondVar);
      updateAria();
    }
    function finish() {
      active = null;
      handle.classList.remove('dragging');
      document.body.classList.remove('resizing-panels');
      document.body.style.removeProperty('--resize-cursor');
    }
    handle.addEventListener('pointerdown', e => {
      if (e.button !== 0 || document.querySelector('.panel.expanded')) return;
      e.preventDefault();
      handle.focus({preventScroll:true});
      const {factor, current} = metrics();
      active = {id:e.pointerId, start:e[coord], size:current, factor};
      handle.setPointerCapture(e.pointerId);
      handle.classList.add('dragging');
      document.body.classList.add('resizing-panels');
      document.body.style.setProperty('--resize-cursor', axis === 'x' ? 'col-resize' : 'row-resize');
    });
    handle.addEventListener('pointermove', e => {
      if (active && active.id === e.pointerId) change(active.size + (e[coord] - active.start) / active.factor);
    });
    handle.addEventListener('pointerup', e => {
      if (active && active.id === e.pointerId) {
        if (handle.hasPointerCapture(e.pointerId)) handle.releasePointerCapture(e.pointerId);
        finish();
      }
    });
    handle.addEventListener('pointercancel', finish);
    handle.addEventListener('lostpointercapture', finish);
    window.addEventListener('blur', finish);
    handle.addEventListener('dblclick', reset);
    handle.addEventListener('keydown', e => {
      const positive = axis === 'x' ? 'ArrowRight' : 'ArrowDown';
      const negative = axis === 'x' ? 'ArrowLeft' : 'ArrowUp';
      if (![positive, negative, 'Home', 'End'].includes(e.key)) return;
      e.preventDefault();
      const {current, total} = metrics();
      const amount = e.shiftKey ? 30 : 10;
      change(e.key === 'Home' ? minimum : e.key === 'End' ? total - otherMinimum : current + (e.key === positive ? amount : -amount));
    });
    new ResizeObserver(updateAria).observe(parent);
    document.querySelector('[data-action="reset"]').addEventListener('click', reset);
    updateAria();
  }
  const left=document.querySelector('.column.left'),uart=document.getElementById('uart'),meter=document.getElementById('ca');
  if(left&&uart&&meter)install({id:'uart-ca-split',parent:left,first:uart,axis:'y',firstVar:'--uart-fr',secondVar:'--ca-fr',minimum:240,otherMinimum:220,orientation:'horizontal',label:'调整串口通信与色彩分析仪高度'});
  install({id:'code-chart-split', parent:upper, first:code, axis:'x', firstVar:'--code-fr', secondVar:'--chart-fr', minimum:230, otherMinimum:260, orientation:'vertical', label:'调整脚本编辑与测量结果宽度'});
  install({id:'upper-recipe-split', parent:center, first:upper, axis:'y', firstVar:'--upper-fr', secondVar:'--recipe-fr', minimum:230, otherMinimum:260, orientation:'horizontal', label:'调整上半工作区与配方区高度'});
})();
