﻿$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$log = Join-Path $env:LOCALAPPDATA 'ElecTest2026\launcher.log'
New-Item -ItemType Directory -Path (Split-Path $log -Parent) -Force | Out-Null
function Write-Log([string]$text) { $text | Tee-Object -FilePath $log -Append }
Write-Log ('--- ' + (Get-Date -Format o) + ' ---')
Write-Log ('Folder: ' + $root)
Write-Log ('64-bit Windows: ' + [Environment]::Is64BitOperatingSystem)
$system = if ([Environment]::Is64BitOperatingSystem) { Join-Path $env:windir 'SysWOW64' } else { Join-Path $env:windir 'System32' }
foreach ($name in 'VCRUNTIME140.dll','MSVCP140.dll','MSVCR100.dll') {
    Write-Log ($name + ': ' + (Test-Path (Join-Path $system $name)))
}
foreach ($name in 'ElecTest2026.exe.config','CASDK2Net.dll','WebView2Loader.dll','Microsoft.Web.WebView2.Core.dll','Microsoft.Web.WebView2.WinForms.dll','Web\index.html') {
    Write-Log ($name + ': ' + (Test-Path (Join-Path $root $name)))
}
$start = Get-Date
try {
    $process = Start-Process -FilePath (Join-Path $root 'ElecTest2026.exe') -WorkingDirectory $root -PassThru
    Write-Log ('Process ID: ' + $process.Id)
    if ($process.WaitForExit(10000)) {
        $process.Refresh()
        Write-Log ('Exited; code=' + $process.ExitCode)
    } else { Write-Log 'Process still running after 10 seconds; check its window or taskbar.' }
} catch { Write-Log ($_ | Out-String) }
try {
    Get-WinEvent -FilterHashtable @{LogName='Application'; StartTime=$start.AddSeconds(-2)} -ErrorAction Stop |
        Where-Object { $_.Message -match 'ElecTest2026' } | Select-Object -First 5 |
        ForEach-Object { Write-Log ($_.TimeCreated.ToString('o') + ' ' + $_.ProviderName + ' ' + $_.Message) }
} catch { Write-Log 'No matching readable Windows application events found.' }
Write-Log ('Launcher log: ' + $log)
Write-Log ('Program log: ' + (Join-Path $env:LOCALAPPDATA 'ElecTest2026\startup.log'))
