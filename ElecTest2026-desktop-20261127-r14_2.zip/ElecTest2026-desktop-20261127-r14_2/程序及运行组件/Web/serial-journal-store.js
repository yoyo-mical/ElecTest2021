'use strict';
// Bounded recent-memory journal only. No automatic disk writes, retries or UART calls.
(() => {
 class Store{
  constructor({records=1000,payload=1048576,entry=4096}={}){if(!Number.isInteger(records)||records<1||payload<entry||entry<1)throw Error('日志容量无效');this.capacity=records;this.maxPayload=payload;this.maxEntry=entry;this.items=new Array(records);this.head=0;this.count=0;this.payload=0;this.omitted=0;this.seq=0;this.mode='detail';}
  clear(){this.items.fill(undefined);this.head=0;this.count=0;this.payload=0;this.omitted=0;}
  push(kind,bytes=[],message='',summary=false,port=''){
   if(this.mode==='off')return null;const detail=this.mode==='detail'&&!summary&&(kind==='TX'||kind==='RX');const data=detail?Uint8Array.from(bytes.slice(0,this.maxEntry)):null;
   const item={id:++this.seq,time:Date.now(),kind,total:bytes.length,data,message:String(message).slice(0,500),port:String(port).slice(0,100),capture:detail?'detail':'summary',truncated:detail&&data.length<bytes.length};
   while(this.count&&(this.count>=this.capacity||this.payload+(data?.length||0)>this.maxPayload)){const old=this.items[this.head];this.payload-=old.data?.length||0;this.items[this.head]=undefined;this.head=(this.head+1)%this.capacity;this.count--;this.omitted++;}
   this.items[(this.head+this.count)%this.capacity]=item;this.count++;this.payload+=data?.length||0;return item;
  }
  recent(limit=this.capacity,filter='all'){const result=[];for(let i=this.count-1;i>=0&&result.length<limit;i--){const item=this.items[(this.head+i)%this.capacity];if(filter==='all'||item.kind===filter)result.push(item);}return result;}
 }
 window.ElecSerialJournalStore=Store;
})();
