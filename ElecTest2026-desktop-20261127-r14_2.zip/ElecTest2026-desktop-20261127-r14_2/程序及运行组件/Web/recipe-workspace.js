'use strict';
// Reparent existing controls only; no recipe semantics or device operations change.
(() => {
 const panel=document.getElementById('recipe'),body=panel.querySelector('.body'),settings=body.querySelector('.recipe-settings'),parameters=body.querySelector('.control-inputs');
 const heading=document.createElement('div');heading.className='recipe-step-heading';heading.textContent='步骤参数';settings.prepend(heading);parameters.querySelector('summary').textContent='图案参数';
 const locate=document.getElementById('goto');locate.parentNode.firstChild.textContent='定位行';locate.setAttribute('aria-label','定位到配方行');
 const modes=body.querySelector('.recipe-modes'),header=panel.querySelector('.panel-header');document.getElementById('table-mode').textContent='步骤表';document.getElementById('text-mode').textContent='自由文本';
 const selectors=['.recipe-command-area','.recipe-modes','#raw-recipe-wrap','#recipe-table','.recipe-footer'];const rightNodes=selectors.map(s=>body.querySelector(s));
 const originals=[settings,parameters,...rightNodes].map(node=>{const marker=document.createComment('recipe-origin');node.before(marker);return {node,marker};});
 const layout=document.createElement('div');layout.className='recipe-workspace';const left=document.createElement('div'),right=document.createElement('div');left.className='recipe-workspace-left';right.className='recipe-workspace-right';body.append(layout);layout.append(left,right);
 let expanded=false,previousOpen=false,active=null;const controls=[];
 function install(id,parent,axis,variable,initial,min,remaining){const h=document.createElement('div');h.id=id;h.className='recipe-workspace-split '+(axis==='x'?'vertical':'horizontal');h.tabIndex=0;h.setAttribute('role','separator');h.setAttribute('aria-orientation',axis==='x'?'vertical':'horizontal');h.setAttribute('aria-label',axis==='x'?'调整配方参数与编辑区宽度':'调整步骤参数与图案参数高度');parent.append(h);let value=null;
  function size(){return axis==='x'?parent.clientWidth:parent.clientHeight;}
  function apply(next){if(!expanded)return;const hi=Math.max(min,size()-10-remaining);value=Math.round(Math.max(min,Math.min(hi,next)));parent.style.setProperty(variable,value+'px');h.setAttribute('aria-valuemin',min);h.setAttribute('aria-valuemax',hi);h.setAttribute('aria-valuenow',value);}
  const defaultValue=()=>axis==='x'?initial:size()*initial;
  function stop(){if(active?.h!==h)return;const p=active.pointer;active=null;h.classList.remove('dragging');if(h.hasPointerCapture(p))h.releasePointerCapture(p);}
  h.onpointerdown=e=>{if(e.button||!expanded)return;apply(value??defaultValue());const box=parent.getBoundingClientRect();active={h,pointer:e.pointerId,start:axis==='x'?e.clientX:e.clientY,value,scale:(axis==='x'?box.width/parent.offsetWidth:box.height/parent.offsetHeight)||1};h.setPointerCapture(e.pointerId);h.classList.add('dragging');e.preventDefault();};
  h.onpointermove=e=>{if(active?.h===h&&active.pointer===e.pointerId)apply(active.value+((axis==='x'?e.clientX:e.clientY)-active.start)/active.scale);};h.onpointerup=stop;h.onpointercancel=stop;h.onlostpointercapture=()=>{if(active?.h===h){active=null;h.classList.remove('dragging');}};
  h.ondblclick=()=>apply(defaultValue());h.onkeydown=e=>{const v=value??defaultValue(),delta=e.shiftKey?24:8;let next;if(e.key===(axis==='x'?'ArrowLeft':'ArrowUp'))next=v-delta;else if(e.key===(axis==='x'?'ArrowRight':'ArrowDown'))next=v+delta;else if(e.key==='Home')next=min;else if(e.key==='End')next=size()-10-remaining;else return;e.preventDefault();apply(next);};
  new ResizeObserver(()=>{if(expanded)apply(value??defaultValue());}).observe(parent);controls.push({stop,refresh:()=>apply(value??defaultValue()),reset:()=>{value=null;parent.style.removeProperty(variable);if(expanded)requestAnimationFrame(()=>apply(defaultValue()));}});
 }
 install('recipe-workspace-x-split',layout,'x','--recipe-left',360,290,500);install('recipe-workspace-y-split',left,'y','--recipe-top',.44,210,220);
 function sync(){const next=panel.classList.contains('expanded');if(next===expanded)return;expanded=next;if(next){previousOpen=parameters.open;left.prepend(settings);left.append(parameters);right.append(...rightNodes);parameters.open=true;requestAnimationFrame(()=>controls.forEach(c=>c.refresh()));}else{controls.forEach(c=>c.stop());for(const {node,marker}of originals)marker.after(node);parameters.open=previousOpen;header.insertBefore(modes,header.querySelector('.panel-actions'));}}
 new MutationObserver(sync).observe(panel,{attributes:true,attributeFilter:['class']});const reset=actions.reset;actions.reset=function(){const result=reset.apply(this,arguments);controls.forEach(c=>c.reset());return result;};header.insertBefore(modes,header.querySelector('.panel-actions'));sync();
})();
