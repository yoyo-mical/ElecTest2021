'use strict';
// Recipe selection shares the exact library definition/order, but never sends a pattern.
(()=>{
 const select=document.getElementById('control-pattern'),code=document.getElementById('pattern-params');
 const normalize=value=>String(value).trim().replace(/\s+/g,' ').toUpperCase();
 const recipeCode=def=>{
  const parts=String(def[3]).split(',');
  if(!/^[0-3]$/.test(parts[0]))return '';
  const count=[5,3,4,2][Number(parts[0])],tokens=parts.slice(0,count);
  if(tokens.length!==count||!tokens.slice(1).every(v=>/^[0-9a-f]{2}$/i.test(v)))return '';
  return tokens.map(v=>v.padStart(2,'0').toUpperCase()).join(' ');
 };
 const choices=patternDefinitions.map(def=>({def,code:recipeCode(def)}));
 select.replaceChildren(new Option('自定义 / 未选择',''),...choices.map(({def,code})=>{
  const option=new Option(def[0]+(code?'':' · 仅预览'),def[4]);option.disabled=!code;return option;
 }));
 select.removeAttribute('data-native-field');
 function sync(){const match=choices.find(row=>row.code&&row.code===normalize(code.value));select.value=match?.def[4]||'';select.disabled=!!state?.busy;}
 select.addEventListener('change',()=>{
  const row=choices.find(row=>row.def[4]===select.value);if(!row?.code)return;
  code.value=row.code;code.dispatchEvent(new Event('input',{bubbles:true}));
 });
 code.addEventListener('input',sync);code.addEventListener('change',sync);
 addEventListener('native-state',sync);addEventListener('recipe-pattern-sync',sync);sync();
})();
