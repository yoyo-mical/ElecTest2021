'use strict';
// UI changes apply to existing native controls and authoritative results only.
(() => {
 const format=document.querySelector('#code [data-action=format]');format.removeAttribute('data-workspace-secondary');format.lastChild.textContent='格式刷';format.setAttribute('aria-label','格式刷');
 const trash=document.querySelector('#recipe [data-action=delete-row]'),area=document.querySelector('.recipe-command-area');area.append(trash);trash.classList.add('recipe-delete-separated');
 // One ordered toolbar in both main and expanded layouts, retaining the original handlers.
 const edit=area.querySelector('.recipe-edit-toolbar'),run=area.querySelector('.recipe-run-controls'),tail=document.createElement('div');tail.className='recipe-toolbar recipe-edit-toolbar recipe-arrange-tools';
 const button=selector=>document.querySelector('#recipe '+selector),step=run.querySelector('[data-action=step]');step.lastChild.textContent='单步运行';
 const leading=[button('#recipe-format'),button('[data-action=import]'),button('[data-action=export-recipe]')],trailing=[button('[data-action=add]'),button('[data-action=up]'),button('[data-action=down]'),button('#bold-recipe'),button('#italic-recipe')];
 edit.replaceChildren(...leading);run.replaceChildren(button('#run-head'),button('#run-current'),step,button('#recipe-pause-toggle'),button('#native-stop'));tail.append(...trailing);area.replaceChildren(edit,run,tail,trash);
 const receive=document.querySelector('.serial-receive'),heading=receive.firstElementChild,tools=receive.querySelector('.serial-receive-toolbar');heading.classList.add('receive-title-tools');heading.append(tools);
 const gray=document.getElementById('gray').closest('fieldset'),bottom=document.querySelector('#patterns .pattern-bottom'),back=document.getElementById('back'),apply=document.getElementById('apply-back');
 const pair=document.createElement('div');pair.className='pattern-gray-back';gray.before(pair);pair.append(gray);
 const group=document.createElement('fieldset');group.className='pattern-value-group';const legend=document.createElement('legend');legend.textContent='Back · 背景';const fields=document.createElement('div');fields.className='pattern-gray-fields';const label=document.createElement('label');label.className='field';label.append(back);apply.textContent='应用';fields.append(label,apply);group.append(legend,fields);pair.append(group);bottom.hidden=true;
 const note=document.getElementById('pattern-apply-status');note.hidden=true;
 const uart=document.getElementById('uart');
 function connection(){const e=document.getElementById('serial-state');if(state?.serialConnected)e.textContent='已连接 · '+(state.fields?.['serial.port']||'');}
 addEventListener('native-state',connection);connection();
 // Chart options use separate full-width rows instead of squeezing controls into one line.
 const chartOptions=document.querySelector('#chart .chart-options');chartOptions.querySelector('summary').setAttribute('aria-label','图表设置');chartOptions.querySelector('summary').title='图表设置';chartOptions.querySelector('h3').textContent='图表设置';
 const zoomRow=chartOptions.querySelector('.chart-tools>.row'),zoomLabel=document.createElement('span');zoomLabel.textContent='缩放';zoomRow.prepend(zoomLabel);document.getElementById('zoom-in').append(document.createTextNode('放大'));document.getElementById('zoom-out').append(document.createTextNode('还原'));
 for(const info of chartOptions.querySelectorAll('.chart-foot,.chart-note'))info.hidden=true;
 // Rectangle selection uses stable row/column coordinates; it never removes points.
 for(const id of ['measurement-table','measurement-all-table']){
  const table=document.getElementById(id),bar=table.closest('.chart-measure-sheet').querySelector('.measurement-toolbar');let selection=null,dragging=false,moved=false;
  const all=document.createElement('button'),part=document.createElement('button');all.type=part.type='button';all.textContent='复制全部';part.textContent='复制选中';part.disabled=true;bar.append(all,part);
  const position=cell=>({r:cell.parentElement.sectionRowIndex,c:cell.cellIndex});
  function paint(){if(!selection)return;const {a,b}=selection;for(const row of table.tBodies[0].rows)for(const cell of row.cells){const p=position(cell);cell.classList.toggle('copy-selected',p.r>=Math.min(a.r,b.r)&&p.r<=Math.max(a.r,b.r)&&p.c>=Math.min(a.c,b.c)&&p.c<=Math.max(a.c,b.c));}part.disabled=false;}
  const scroller=table.closest('.measurement-scroll');let pointer=null,frame=0,lastFrame=0;
  function endpoint(cell){if(!cell||!table.contains(cell))return;const next=position(cell);if(selection.b.r!==next.r||selection.b.c!==next.c){selection.b=next;moved=true;paint();}}
  function bounds(){const box=scroller.getBoundingClientRect(),header=table.tHead.getBoundingClientRect();const left=box.left+scroller.clientLeft,top=box.top+scroller.clientTop;return {left:Math.max(0,left+1),right:Math.min(innerWidth,left+scroller.clientWidth-2),top:Math.max(0,top+Math.min(header.height,scroller.clientHeight-2)+1),bottom:Math.min(innerHeight,top+scroller.clientHeight-2)};}
  function hit(){if(!pointer||!selection||!scroller.clientHeight)return;const box=bounds();if(box.bottom<=box.top||box.right<=box.left)return;const x=Math.max(box.left,Math.min(box.right,pointer.x)),y=Math.max(box.top,Math.min(box.bottom,pointer.y));endpoint(document.elementFromPoint(x,y)?.closest('tbody td'));}
  function scrollDrag(now){frame=0;if(!dragging||!pointer||!scroller.clientHeight)return;const box=bounds(),elapsed=Math.min(2,Math.max(.25,(now-lastFrame)/16.67));lastFrame=now;
   const velocity=(value,low,high)=>value<low+28?-18*Math.min(1,(low+28-value)/28):value>high-28?18*Math.min(1,(value-high+28)/28):0;
   const top=scroller.scrollTop,left=scroller.scrollLeft;scroller.scrollTop+=velocity(pointer.y,box.top,box.bottom)*elapsed;scroller.scrollLeft+=velocity(pointer.x,box.left,box.right)*elapsed;
   if(top!==scroller.scrollTop||left!==scroller.scrollLeft){moved=true;hit();}frame=requestAnimationFrame(scrollDrag);
  }
  function finish(){dragging=false;pointer=null;delete table.dataset.copySelecting;if(frame)cancelAnimationFrame(frame);frame=0;}
  table.addEventListener('pointerdown',e=>{const cell=e.target.closest('tbody td');if(!cell||e.button!==0)return;finish();const p=position(cell);selection={a:e.shiftKey&&selection?selection.a:p,b:p};dragging=true;moved=!!e.shiftKey;pointer={x:e.clientX,y:e.clientY};table.dataset.copySelecting='true';lastFrame=performance.now();frame=requestAnimationFrame(scrollDrag);paint();table.focus({preventScroll:true});e.preventDefault();});
  table.addEventListener('pointerover',e=>{if(dragging)endpoint(e.target.closest('tbody td'));});
  document.addEventListener('pointermove',e=>{if(!dragging)return;pointer={x:e.clientX,y:e.clientY};hit();});
  document.addEventListener('pointerup',finish);document.addEventListener('pointercancel',finish);addEventListener('blur',finish);
  table.addEventListener('keydown',e=>{if(e.key==='Escape')finish();});
  table.addEventListener('click',e=>{if(moved){e.stopPropagation();moved=false;}},true);
  function text(selected){const cells=[...table.tBodies[0].rows].map(row=>[...row.cells]);if(!cells.length)return '';let r0=0,r1=cells.length-1,c0=0,c1=cells[0].length-1;if(selected){if(!selection)return '';r0=Math.min(selection.a.r,selection.b.r);r1=Math.min(cells.length-1,Math.max(selection.a.r,selection.b.r));c0=Math.min(selection.a.c,selection.b.c);c1=Math.max(selection.a.c,selection.b.c);}
   const headers=selected?[]:[...table.tHead.rows].map(row=>{const expanded=[];for(const cell of row.cells)for(let i=0;i<cell.colSpan;i++)expanded.push(cell.innerText);return expanded.slice(c0,c1+1).join('\t');});
   return headers.concat(cells.slice(r0,r1+1).map(row=>row.slice(c0,c1+1).map(c=>c.innerText).join('\t'))).join('\r\n');
  }
  const copy=selected=>{const value=text(selected);if(value)native('clipboard.copy',{text:value}).catch(e=>notify(e.message));};all.onclick=()=>copy(false);part.onclick=()=>copy(true);
  table.tabIndex=0;table.addEventListener('keydown',e=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='c'&&selection){e.preventDefault();copy(true);}});
  // Keep selection across chart pinning/state refresh without observing our class changes.
  new MutationObserver(paint).observe(table.tBodies[0],{childList:true,subtree:true});
 }
})();
