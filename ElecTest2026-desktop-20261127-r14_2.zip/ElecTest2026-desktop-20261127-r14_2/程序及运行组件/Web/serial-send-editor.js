'use strict';
(() => {
 const input=document.getElementById('send-data'),row=input.closest('.send-row'),modes=document.querySelector('#uart input[name=encoding]').closest('.radio-row');
 const tools=document.createElement('div');tools.className='serial-input-toolbar';tools.innerHTML='<span id="serial-byte-count" role="status">等待输入</span><button id="serial-format-input" type="button">格式化 / 检查</button>';row.prepend(tools);
 const feedback=document.createElement('p');feedback.id='serial-input-feedback';feedback.className='serial-input-feedback';feedback.hidden=true;feedback.setAttribute('role','status');feedback.setAttribute('aria-live','polite');input.setAttribute('aria-describedby','serial-byte-count serial-input-feedback');row.after(feedback);
 function mode(){return modes.querySelector('input:checked').value==='HEX'?'HEX':'ASCII';}
 function markError(error,locate){input.setAttribute('aria-invalid',String(error.code!=='FORMAT_LIMIT'));feedback.hidden=false;feedback.classList.add('error');feedback.textContent=error.message;document.getElementById('serial-byte-count').textContent=error.code==='FORMAT_LIMIT'?'排版超出上限':'格式有误';if(locate&&Number.isInteger(error.index)){input.focus();input.setSelectionRange(error.index,error.index+(error.length||1));const line=input.value.slice(0,error.index).split('\n').length;input.scrollTop=Math.max(0,(line-2)*(parseFloat(getComputedStyle(input).lineHeight)||17));}}
 let formatting=false;
 function check(format=false){
  try{
   const result=ElecSerialInput.parse(input.value,mode(),document.getElementById('send-ending').value,format);input.setAttribute('aria-invalid','false');document.getElementById('serial-byte-count').textContent=result.bytes.length+' 字节';feedback.classList.remove('error');
   if(format){if(mode()==='HEX'){input.value=result.text;formatting=true;input.dispatchEvent(new Event('input',{bubbles:true}));formatting=false;feedback.textContent='已规范为两位一组、每行16字节；未发送，也未补充协议内容。';}else feedback.textContent='ASCII检查通过，空格和换行保持原样；未发送。';feedback.hidden=false;}
   else feedback.hidden=true;
   return true;
  }catch(error){markError(error,format);return false;}
 }
 document.getElementById('serial-format-input').onclick=()=>{clearTimeout(timer);check(true);};
 let timer;input.addEventListener('input',()=>{if(formatting)return;clearTimeout(timer);timer=setTimeout(()=>check(false),150);});
 modes.addEventListener('change',()=>{document.getElementById('serial-format-input').textContent=mode()==='HEX'?'格式化 / 检查':'检查文本';check(false);});
 document.getElementById('send-ending').addEventListener('change',()=>check(false));
 addEventListener('electest:serial-input-error',e=>markError(e.detail,true));
 const reset=actions.reset;actions.reset=function(){const result=reset.apply(this,arguments);clearTimeout(timer);feedback.hidden=true;input.setAttribute('aria-invalid','false');check(false);return result;};
 function lock(){document.getElementById('serial-format-input').disabled=!!running;}
 new MutationObserver(lock).observe(document.getElementById('run-state'),{childList:true,subtree:true,characterData:true});lock();
 check(false);
})();
