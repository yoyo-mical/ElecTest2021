'use strict';
(() => {
 const chart=document.getElementById('chart'),api=window.ElecMeasurements,tabs=chart.querySelector('.chart-tabs');
 const label=document.createElement('label');label.className='result-single-group';
 const select=document.createElement('select');select.id='result-single-group';select.setAttribute('aria-label','单图测量组');label.append(select);tabs.querySelector('.chart-tab-spacer').after(label);
 const orderLabel=document.createElement('label');orderLabel.textContent='横轴';const order=document.createElement('select');order.id='result-axis-order';order.setAttribute('aria-label','结果横轴顺序');for(const [value,title]of [['recipe','配方顺序'],['ascending','从小到大'],['descending','从大到小']])order.add(new Option(title,value));orderLabel.append(order);chart.querySelector('.chart-options-menu .chart-tools').append(orderLabel);
 order.onchange=()=>{if(state?.busy)return;const groups=window.ElecChartWorkspace.mode()==='gallery'?window.ElecMeasurementSheet.groups():[api.snapshot()];for(const g of groups)if(g.completed!==false)measurementAxisOrders.set(String(g.runId),order.value);renderChart();dispatchEvent(new Event('electest:axis-order'));};
 let signature='';
 function sync(){const groups=window.ElecMeasurementSheet.groups(),id=api.viewedRunId(),key=JSON.stringify([id,groups.map(g=>[g.runId,g.title,g.deleted])]);if(key!==signature){signature=key;const live=document.createElement('option');live.value='live';live.textContent='当前采集组';select.replaceChildren(live);for(const g of groups){const option=document.createElement('option');option.value=String(g.runId);option.textContent=groupLabel(g)+' · '+g.title;select.append(option);}if(id!==null&&!groups.some(g=>String(g.runId)===String(id))){const deleted=document.createElement('option');deleted.value=String(id);deleted.textContent='第 '+id+' 组 · 已删除';select.append(deleted);}select.value=id===null?'live':String(id);}
  order.disabled=!!state?.busy;order.value=measurementAxisOrders.get(String(api.snapshot().runId))||'recipe';
  const mode=window.ElecChartWorkspace.mode();label.hidden=!['curve','sheet','both'].includes(mode);
 }
 select.onchange=()=>{api.viewGroup(select.value==='live'?null:Number(select.value));};
 addEventListener('electest:measurement-view',sync);addEventListener('electest:sheet-groups',sync);addEventListener('electest:results-mode',sync);sync();
})();
