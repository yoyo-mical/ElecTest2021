'use strict';
// Move the existing appearance controls into one panel; keep their native handlers and saved values.
(() => {
 const bar=document.querySelector('.top-right'),controls=['theme','font-scale','interface-scale'].map(id=>document.getElementById(id).closest('label'));
 bar.querySelector(':scope>.row')?.remove();
 const menu=document.createElement('details');menu.id='appearance-settings';menu.className='appearance-settings';
 const trigger=document.createElement('summary');trigger.textContent='外观设置';trigger.setAttribute('aria-label','主题、字体和界面设置');
 const content=document.createElement('div');content.className='appearance-settings-panel';content.append(...controls);menu.append(trigger,content);bar.insertBefore(menu,bar.querySelector('[data-action=reset]')); 
 document.addEventListener('pointerdown',e=>{if(!menu.contains(e.target))menu.open=false;});
 menu.addEventListener('keydown',e=>{if(e.key==='Escape'){e.preventDefault();e.stopPropagation();menu.open=false;trigger.focus();}});
})();
