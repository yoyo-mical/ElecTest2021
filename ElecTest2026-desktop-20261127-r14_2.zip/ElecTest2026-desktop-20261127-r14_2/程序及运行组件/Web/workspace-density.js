'use strict';
// One DOM and one set of handlers: only presentation changes between the main and expanded workspaces.
(() => {
 const panels=[...document.querySelectorAll('.panel')];
 for(const button of document.querySelectorAll('#code .mini-toolbar button,#recipe-format'))button.removeAttribute('title');
 function secondary(selector){for(const node of document.querySelectorAll(selector))node.dataset.workspaceSecondary='true';}
 secondary('#rx-demo,#serial-ascii,#uart .serial-manual-send');
 secondary('#ca .metric:nth-child(3),#ca .metric:nth-child(4),#ca .metric:nth-child(5),#ca .metric:nth-child(8)');
 secondary('#code [data-action=comment],#code .voltage');
 secondary('#chart [data-chart-view=gallery],#chart-combined-tab,#measurement-all-tab,#chart .chart-options,#chart .measurement-note,#measurement-open-original');
 secondary('#recipe .recipe-settings,#recipe .control-inputs,#recipe-mode-note,#recipe .recipe-footer,#raw-recipe-wrap>small');
 secondary('#pattern-apply-status,#patterns .pattern-bottom,#pattern-disclosure');
 const summaries={uart:'手动发送、接收演示和转换工具',ca:'更多测量明细',code:'模块、注释和参数',chart:'多图、组合视图和图表设置',recipe:'编辑、参数和其他运行操作',patterns:'图案筛选、预览和背景参数'};
 for(const panel of panels){
  const button=document.createElement('button');button.className='icon workspace-more';button.type='button';button.textContent='⋯';button.title=summaries[panel.id];button.setAttribute('aria-label',summaries[panel.id]);button.setAttribute('aria-expanded','false');button.dataset.workspaceMore=panel.id;
  panel.querySelector('[data-expand]').before(button);
  button.onclick=()=>{const open=panel.classList.toggle('workspace-details-open');button.setAttribute('aria-expanded',String(open));button.title=(open?'收起':'显示')+summaries[panel.id];};
 }
 const observer=new MutationObserver(()=>{for(const panel of panels){const button=panel.querySelector('.workspace-more');button.setAttribute('aria-expanded',String(panel.classList.contains('expanded')||panel.classList.contains('workspace-details-open')));}});
 for(const panel of panels)observer.observe(panel,{attributes:true,attributeFilter:['class']});
})();
