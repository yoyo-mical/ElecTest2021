'use strict';
// Shared layout tools use real native state and fixed C# operations, never demo producers.
(() => {
 const status=document.getElementById('pattern-apply-status');status.textContent='RGB 与 Gray 独立保存；点击应用发送。';
 for(const [id,mode] of [['apply-rgb','rgb'],['apply-gray','gray']])document.getElementById(id).onclick=safe(async()=>{
  const ids=mode==='rgb'?['red','green','blue']:['gray'];const values=ids.map(id=>{const raw=document.getElementById(id).value;const n=Number(raw);if(!raw.trim()||!Number.isInteger(n)||n<0||n>255)throw Error('请输入 0–255 的整数。');return n;});
  await command('pattern.'+mode);status.textContent=(mode==='rgb'?'RGB：'+values.join(' / '):'Gray：'+values[0]+' → '+[values[0],values[0],values[0]].join(' / '))+'，原 C# 发送流程已返回。';
 });
})();
