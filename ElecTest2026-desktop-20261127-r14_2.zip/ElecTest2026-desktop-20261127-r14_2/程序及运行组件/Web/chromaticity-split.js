'use strict';
(() => {
 const panel=document.getElementById('ca'),body=panel.querySelector('.body'),analysis=panel.querySelector('.cie-analysis-content');
 const handles=[];let active=null;
 function add(id,parent,variable,initial,min,max,reverse){
  const handle=document.createElement('div');handle.id=id;handle.className='cie-split';handle.tabIndex=0;handle.setAttribute('role','separator');handle.setAttribute('aria-orientation','vertical');handle.setAttribute('aria-label',reverse?'调整色度图与分析设置宽度':'调整读数与色度图宽度');handle.title='拖动调整宽度；方向键微调；双击恢复';
  parent.append(handle);let value=initial;
  function limits(){return [min,Math.max(min,Math.min(max,parent.clientWidth-(reverse?320:620)))];}
  function apply(next){const [lo,hi]=limits();value=Math.round(Math.max(lo,Math.min(hi,next)));parent.style.setProperty(variable,value+'px');handle.setAttribute('aria-valuemin',lo);handle.setAttribute('aria-valuemax',hi);handle.setAttribute('aria-valuenow',value);handle.setAttribute('aria-valuetext',value+' 像素');}
  function stop(){if(active?.handle!==handle)return;const pointerId=active.pointerId;active=null;handle.classList.remove('dragging');if(handle.hasPointerCapture(pointerId))handle.releasePointerCapture(pointerId);}
  handle.onpointerdown=e=>{if(e.button!==0||!panel.classList.contains('expanded'))return;apply(value);active={handle,pointerId:e.pointerId,x:e.clientX,value,scale:parent.getBoundingClientRect().width/parent.offsetWidth||1};handle.setPointerCapture(e.pointerId);handle.classList.add('dragging');e.preventDefault();};
  handle.onpointermove=e=>{if(active?.handle!==handle||active.pointerId!==e.pointerId)return;apply(active.value+(reverse?-1:1)*(e.clientX-active.x)/active.scale);};
  handle.onpointerup=stop;handle.onpointercancel=stop;handle.onlostpointercapture=()=>{if(active?.handle===handle){active=null;handle.classList.remove('dragging');}};
  handle.ondblclick=()=>apply(initial);
  handle.onkeydown=e=>{let next;if(e.key==='ArrowLeft')next=value+(reverse?1:-1)*(e.shiftKey?24:8);else if(e.key==='ArrowRight')next=value+(reverse?-1:1)*(e.shiftKey?24:8);else if(e.key==='Home')next=limits()[0];else if(e.key==='End')next=limits()[1];else return;e.preventDefault();apply(next);};
  new ResizeObserver(()=>{if(parent.clientWidth&&handle.getBoundingClientRect().width)apply(value);}).observe(parent);
  new MutationObserver(()=>{if(!panel.classList.contains('expanded'))stop();}).observe(panel,{attributes:true,attributeFilter:['class']});
  handle.setAttribute('aria-valuemin',min);handle.setAttribute('aria-valuemax',max);handle.setAttribute('aria-valuenow',initial);handles.push({handle,reset:()=>{value=initial;parent.style.setProperty(variable,initial+'px');handle.setAttribute('aria-valuenow',initial);}});
 }
 add('cie-readout-split',body,'--cie-readout-width',310,260,450,false);
 add('cie-analysis-split',analysis,'--cie-tools-width',225,190,360,true);
 // Reset is an explicit user action; ordinary expand/restore preserves both widths.
 const reset=actions.reset;actions.reset=function(){const result=reset.apply(this,arguments);for(const item of handles)item.reset();return result;};
})();
