'use strict';
// The host changes WebView2.ZoomFactor; no CSS transform or bitmap scaling is used.
(() => {
 const label=document.createElement('label');label.className='interface-scale-label';label.append(document.createTextNode('界面'));
 const select=document.createElement('select');select.id='interface-scale';select.setAttribute('aria-label','整体界面缩放');for(const n of [100,115,125,150,175,200])select.add(new Option(n+'%',String(n)));label.append(select);document.getElementById('font-scale').closest('label').after(label);
 let pending=false;
 function sync(){if(pending)return;const value=String(state?.uiScale||100);if([...select.options].some(o=>o.value===value))select.value=value;}
 select.onchange=async()=>{const value=Number(select.value);pending=true;select.disabled=true;try{const reply=await native('ui.scale',{uiScale:value});applyState(reply.state);}catch(error){notify('界面缩放未保存：'+error.message);}finally{pending=false;select.disabled=false;sync();}};
 addEventListener('native-state',sync);sync();
})();
