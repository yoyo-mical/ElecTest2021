'use strict';
(() => {
 const $=id=>document.getElementById(id),panel=$('uart'),assist=panel.querySelector('.uart-assist-area'),convert=$('serial-ascii'),store=new ElecSerialJournalStore();
 const tabs=document.createElement('div');tabs.className='uart-assist-tabs';tabs.innerHTML='<button id="uart-assist-convert" aria-pressed="true">文本转换</button><button id="uart-assist-log" aria-pressed="false">收发日志</button>';assist.prepend(tabs);
 const view=document.createElement('section');view.id='uart-log-tools';view.className='uart-log-tools';view.hidden=true;view.innerHTML='<div class="uart-tool-row"><label>记录<select id="uart-log-mode"><option value="detail">详细（配方期间自动摘要）</option><option value="summary">仅摘要</option><option value="off">暂停记录</option></select></label><label>查看<select id="uart-log-filter"><option value="all">全部</option><option value="TX">发送 TX</option><option value="RX">接收 RX</option><option value="ERROR">异常</option><option value="INFO">连接状态</option></select></label><button id="uart-log-clear">清空日志</button><button id="uart-log-export">导出全部近期 CSV</button></div><p id="uart-log-status" role="status"></p><small>仅本次页面的近期收发记录：最多1000条、1MiB载荷；每条详细内容最多4096字节，超出会标注。列表显示最近100条，旧记录自动移出并计数；不是完整归档。本版不自动写文件或轮转；配方期间记录摘要。切换显示不会测量或发送。</small><div class="uart-journal-scroll"><table><thead><tr><th>时间</th><th>方向</th><th>字节</th><th>内容预览</th></tr></thead><tbody id="uart-log-rows"></tbody></table></div><pre id="uart-log-selected">点选记录查看内容。TX写出不代表设备执行成功；RX批次不代表完整回复。</pre>';assist.append(view);
 let active='convert',linkedPort=serial?$('port').value:'',dirty=true,timer=null;
 const hex=values=>Array.from(values,b=>b.toString(16).toUpperCase().padStart(2,'0')).join(' ');
 const stamp=ms=>new Date(ms).toLocaleTimeString('zh-CN',{hour12:false})+'.'+String(ms%1000).padStart(3,'0');
 function render(){dirty=false;const rows=$('uart-log-rows');rows.replaceChildren();const items=store.recent(100,$('uart-log-filter').value);for(const item of items){const tr=rows.insertRow();tr.tabIndex=0;tr.insertCell().textContent=stamp(item.time);tr.insertCell().textContent=item.kind;tr.insertCell().textContent=item.total;tr.insertCell().textContent=item.data?(hex(item.data.slice(0,24))+(item.data.length>24?' …':'')+(item.truncated?' [内容截断]':'')):(item.message||'摘要：未保存字节内容');const select=()=>{$('uart-log-selected').textContent='#'+item.id+' · '+stamp(item.time)+' · '+item.port+' · '+item.kind+' · '+item.total+' 字节\n'+(item.data?'HEX：'+hex(item.data)+'\nASCII：'+ElecSerialAscii.decode(hex(item.data)).text:'仅摘要，未保存字节内容。')+(item.truncated?'\n仅记录前'+item.data.length+'字节，其余未保留。':'')+(item.message?'\n'+item.message:'');};tr.onclick=select;tr.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();select();}};}
  $('uart-log-status').textContent='保留 '+store.count+' / 1000 条 · 载荷 '+store.payload+' / 1048576 字节 · 已移出 '+store.omitted+' 条 · 当前列表 '+items.length+' 条'+(running?' · 配方期间仅摘要':'');$('uart-log-export').disabled=!!running;
 }
 function queue(){dirty=true;if(timer||!panel.classList.contains('expanded')||active!=='log')return;timer=setTimeout(()=>{timer=null;if(panel.classList.contains('expanded')&&active==='log')render();},200);}
 function record(kind,bytes,message,total){const item=store.push(kind,bytes,message,!!running,linkedPort);if(item){if(Number.isInteger(total)){item.total=total;item.truncated=!!item.data&&item.data.length<total;}queue();}}
 function select(next){active=next;const expanded=panel.classList.contains('expanded');convert.hidden=expanded&&next==='log';view.hidden=!expanded||next!=='log';$('uart-assist-convert').setAttribute('aria-pressed',String(next==='convert'));$('uart-assist-log').setAttribute('aria-pressed',String(next==='log'));if(expanded&&next==='log')render();}
 $('uart-assist-convert').onclick=()=>select('convert');$('uart-assist-log').onclick=()=>select('log');addEventListener('electest:uart-layout',()=>select(active));
 $('uart-log-mode').onchange=()=>{store.mode=$('uart-log-mode').value;native('serial.logMode',{text:store.mode}).catch(e=>notify(e.message));render();};$('uart-log-filter').onchange=render;
 $('uart-log-clear').onclick=()=>{if(store.count&&!confirm('仅清空近期收发日志？接收区和发送输入不受影响。'))return;store.clear();$('uart-log-selected').textContent='日志已清空，收发内容未改变。';render();};
 const csv=value=>{let text=String(value??'');if(/^[=+@-]/.test(text))text="'"+text;return '"'+text.replaceAll('"','""')+'"';};
 $('uart-log-export').onclick=()=>{if(!running)native('serial.logExport').catch(e=>notify(e.message));};
 addEventListener('electest:serial-tx',e=>record('TX',e.detail.bytes,'串口写出；不代表设备执行成功。',e.detail.total));
 addEventListener('electest:serial-rx',e=>record('RX',e.detail.bytes,'串口接收批次；未组包。',e.detail.total));
 addEventListener('electest:serial-write-error',e=>record('ERROR',[],e.detail.message));
 addEventListener('electest:serial-input-error',e=>record('ERROR',[],'输入校验失败，未发送：'+e.detail.message));
 addEventListener('electest:serial-connection',e=>{if(e.detail.connected)linkedPort=e.detail.port;record('INFO',[],e.detail.connected?'串口已连接。':'串口已断开。');if(!e.detail.connected)linkedPort='';});
 new MutationObserver(()=>{$('uart-log-export').disabled=!!running;queue();}).observe($('run-state'),{childList:true,subtree:true,characterData:true});
 const reset=actions.reset;actions.reset=function(){const result=reset.apply(this,arguments);clearTimeout(timer);timer=null;store.clear();linkedPort='';render();return result;};
 window.ElecSerialJournal={snapshot:()=>({count:store.count,payload:store.payload,omitted:store.omitted,mode:store.mode,records:store.recent().map(item=>({...item,data:item.data?Array.from(item.data):null}))})};
 select('convert');
})();
