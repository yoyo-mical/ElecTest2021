'use strict';
(() => {
 const app=document.getElementById('app'),theme=document.getElementById('theme'),label=document.createElement('label');label.textContent='字体';const choice=document.createElement('select');choice.id='font-scale';choice.setAttribute('aria-label','界面字体大小');for(const [value,title]of [['standard','标准 · 100%'],['larger','较大 · 115%'],['large','大 · 130%']])choice.add(new Option(title,value));label.append(choice);theme.closest('label').after(label);
 const factor={standard:1,larger:1.15,large:1.3};
 // Preserve the existing relative hierarchy, all responsive conditions and one editor DOM.
 // Scale font metrics only; never raster-scale/transform the workstation to simulate bigger text.
 function fontRules(rules){let text='';for(const r of rules){if(r.selectorText&&r.style){let props='';for(const key of ['font-size','line-height']){const v=r.style.getPropertyValue(key).trim();if(/^\d*\.?\d+px$/.test(v))props+=key+':calc('+v+' * var(--ui-font-scale,1))!important;';}if(props)text+=r.selectorText+'{'+props+'}\n';}else if(r.cssRules){const nested=fontRules(r.cssRules);if(nested)text+=r.cssText.slice(0,r.cssText.indexOf('{'))+'{'+nested+'}\n';}}return text;}
 const overlay=document.createElement('style');overlay.id='ui-font-metrics';let rules='';for(const sheet of document.styleSheets){try{rules+=fontRules(sheet.cssRules);}catch{ /* only readable same-origin sheets participate */ }}overlay.textContent=rules;document.head.append(overlay);
 function apply(){app.style.setProperty('--ui-font-scale',factor[choice.value]||1);app.dataset.uiFont=choice.value;try{localStorage.setItem('electest.ui-font',choice.value);}catch{}if(typeof renderChart==='function')renderChart();dispatchEvent(new CustomEvent('electest:font-scale',{detail:{value:choice.value,factor:factor[choice.value]}}));}
 choice.onchange=apply;try{const saved=localStorage.getItem('electest.ui-font');if(Object.hasOwn(factor,saved))choice.value=saved;}catch{}apply();
 // Existing theme event updates the root and re-renders plots. Keep that single handler.
 theme.addEventListener('change',()=>{try{localStorage.setItem('electest.ui-theme',theme.value);}catch{}});try{const saved=localStorage.getItem('electest.ui-theme');if([...theme.options].some(o=>o.value===saved)){theme.value=saved;theme.dispatchEvent(new Event('change'));}}catch{}
})();
