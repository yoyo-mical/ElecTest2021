'use strict';
// Step-type presentation only: selection does not add a row, run a recipe or send bytes.
(() => {
 const panel=document.getElementById('recipe'),item=document.getElementById('item'),details=panel.querySelector('.control-inputs'),summary=details.querySelector('summary'),path=document.getElementById('control-path'),choose=document.getElementById('choose-control-file');
 const saveField=document.createElement('label');saveField.className='field';saveField.innerHTML='<span>测量数据保存目录</span><input id="recipe-save-path" aria-label="测量数据保存目录" placeholder="例如 D:\\Measurements">';details.querySelector('.control-fields').append(saveField);const savePath=saveField.querySelector('input');
 const saveRow=document.createElement('div');saveRow.className='recipe-save-picker';savePath.before(saveRow);saveRow.append(savePath);const saveChoose=document.createElement('button');saveChoose.type='button';saveChoose.id='choose-save-folder';saveChoose.textContent='选择文件夹';saveRow.append(saveChoose);
 saveChoose.onclick=safe(async()=>{if(state?.busy)return;saveChoose.disabled=true;try{const reply=await native('recipe.browse',{scope:'save'});if(reply.path){savePath.value=reply.path;savePath.dispatchEvent(new Event('input',{bubbles:true}));}}finally{saveChoose.disabled=!state?.authorized||!!state?.busy;}});
 addEventListener('native-state',()=>{saveChoose.disabled=!state?.authorized||!!state?.busy;});
 const fields={Pattern:[document.getElementById('control-pattern').closest('.field'),document.getElementById('pattern-params').closest('.field')],DownLoad:[document.getElementById('download-content').closest('.field')],Read:[path.closest('.field')],Save:[saveField]};
 const labels=[...details.querySelectorAll('.control-fields>.field')],pathLabel=path.closest('.field').querySelector('span'),help=details.querySelector('small'),empty=document.createElement('p');empty.id='recipe-step-empty';empty.className='recipe-step-empty';details.querySelector('.control-fields').after(empty);
 const settings=panel.querySelector('.recipe-settings');
 for(const [id,label,initial,min,max]of [['recipe-goto-step','从第几步开始（从1计）','1','1','256'],['recipe-goto-count','重复次数','1','0','3000']]){const field=document.createElement('label');field.className='field';field.dataset.goto='true';const title=document.createElement('span');title.textContent=label;const input=document.createElement('input');input.id=id;input.type='number';input.step='1';input.min=min;input.max=max;input.value=initial;input.setAttribute('aria-label',label);field.append(title,input);settings.append(field);}
 const gotoStep=document.getElementById('recipe-goto-step'),gotoCount=document.getElementById('recipe-goto-count');
 function render(switching=false){const type=item.value,full=panel.classList.contains('expanded'),visible=fields[type]||[];for(const f of labels)f.hidden=!full&&!visible.includes(f);
  summary.textContent=full?'附加参数':({Pattern:'图案参数',DownLoad:'下发代码',Read:'读取文件',Save:'保存目录'})[type]||'附加参数';
  empty.hidden=full||visible.length>0;empty.textContent=type==='Goto'?'在步骤参数中填写起始步骤和重复次数，再点“添加步骤”。步骤表和文本中的步骤号都从1开始。':'当前 '+type+' 步骤无需图案、代码或文件路径。';
  help.hidden=!full&&visible.length===0;help.textContent=full?'配置项完整展示；只有选择的项目用于添加步骤。由本机执行所选步骤。':({Pattern:'选择预设可填入图案代码；切换项目不执行步骤。',DownLoad:'填写 DownLoad 步骤的代码内容，不会自动下发。',Read:'选择代码文件或填写完整路径。选择本机代码文件。',Save:'填写本机保存目录；执行Save步骤时写入指定目录。'})[type]||'';
  pathLabel.textContent='Read · 代码文件路径';choose.hidden=!full&&type!=='Read';
  for(const f of panel.querySelectorAll('.recipe-settings>.field')){if(f.contains(item))continue;f.hidden=full?false:type==='Goto'?!f.dataset.goto:!!f.dataset.goto||visible.length>0;}
  if(full)details.open=true;else if(switching)details.open=visible.length>0;
 }
 item.addEventListener('change',()=>render(true));
 const reset=actions.reset;actions.reset=function(){savePath.value='';const result=reset.apply(this,arguments);render();return result;};
 new MutationObserver(()=>render()).observe(panel,{attributes:true,attributeFilter:['class']});render();
})();
