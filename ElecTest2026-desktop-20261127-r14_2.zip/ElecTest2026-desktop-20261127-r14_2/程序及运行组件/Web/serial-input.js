'use strict';
// Byte syntax only: never infer protocol bytes, checksums, register values or missing nibbles.
(() => {
 class InputError extends Error{
  constructor(text,index,length,reason){const lines=text.slice(0,index).split(/\r\n|\r|\n/);super('第 '+lines.length+' 行，第 '+(Array.from(lines.at(-1)).length+1)+' 列：'+reason);this.index=index;this.length=length;this.name='SerialInputError';}
 }
 function parse(text,mode,ending='none',format=false){
  if(text.length>100000)throw new InputError(text,100000,1,'内容过长，最多100000个字符。');
  if(!text.trim())throw new InputError(text,0,1,'请输入发送内容。');
  if(mode==='ASCII'){
   let i=0;for(const c of text){if(c.codePointAt(0)>127)throw new InputError(text,i,c.length,'不是ASCII字符；请确认设备支持的编码，不会自动替换。');i+=c.length;}
   const endings={none:'',cr:'\r',lf:'\n',crlf:'\r\n'};if(!Object.hasOwn(endings,ending))throw new Error('文本结尾选项无效。');
   return {bytes:Array.from(text+endings[ending],c=>c.charCodeAt(0)),text,changed:false};
  }
  if(mode!=='HEX')throw new Error('发送格式无效。');
  const normalized=format?text.replace(/，/g,',').replace(/；/g,';'):text,bytes=[];
  for(const match of normalized.matchAll(/[^\s,;]+/gu)){
   let token=match[0],start=match.index;
   if(/^0x/i.test(token)){if(token.length!==4)throw new InputError(text,start,token.length,'0x后必须是两位十六进制，例如0x52；不会补0或猜测字节。');token=token.slice(2);start+=2;}
   const bad=token.search(/[^0-9a-f]/i);
   if(bad>=0){const c=String.fromCodePoint(token.codePointAt(bad));throw new InputError(text,start+bad,c.length,c==='，'||c==='；'?'发现全角分隔符，可点击“格式化”规范；本次未发送。':'“'+c+'”不是十六进制字符，只接受0–9、A–F。');}
   if(token.length%2)throw new InputError(text,start+token.length-1,1,'这个字节只有一位；每个字节需要两位，不会自动补0。');
   for(let i=0;i<token.length;i+=2)bytes.push(parseInt(token.slice(i,i+2),16));
  }
  if(!bytes.length)throw new InputError(text,0,1,'没有可发送的字节。');
  const rows=[];for(let i=0;i<bytes.length;i+=16)rows.push(bytes.slice(i,i+16).map(b=>b.toString(16).toUpperCase().padStart(2,'0')).join(' '));
  const pretty=rows.join('\n');if(format&&pretty.length>100000){const error=new InputError(text,0,1,'排版后将超过100000字符，输入保持原样；请分段后格式化。');error.code='FORMAT_LIMIT';throw error;}return {bytes,text:pretty,changed:pretty!==text};
 }
 window.ElecSerialInput=Object.freeze({parse});
})();
