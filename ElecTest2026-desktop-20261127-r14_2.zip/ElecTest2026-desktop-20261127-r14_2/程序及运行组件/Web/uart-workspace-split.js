'use strict';
// Rearrange the same nodes only while expanded; restore their exact main-workspace positions.
(() => {
 const panel=document.getElementById('uart'),body=panel.querySelector('.body'),connection=body.querySelector('.serial-connection'),send=body.querySelector('.serial-manual-send'),receive=body.querySelector('.serial-receive'),convert=document.getElementById('serial-ascii');
 const nodes=[connection,send,receive,convert].map(node=>{const marker=document.createComment('uart-layout-origin');node.before(marker);return {node,marker};});
 const left=document.createElement('div'),right=document.createElement('div');left.className='uart-split-left';right.className='uart-split-right';body.append(left,right);const assist=document.createElement('div');assist.className='uart-assist-area';right.append(assist);
 let expanded=false,oldOpen=false,active=null;
 const controls=[];
 function install(id,parent,first,axis,key,initial,minimum,otherMinimum){
  const h=document.createElement('div');h.id=id;h.className='uart-workspace-split '+(axis==='x'?'vertical':'horizontal');h.tabIndex=0;h.setAttribute('role','separator');h.setAttribute('aria-orientation',axis==='x'?'vertical':'horizontal');h.setAttribute('aria-label',axis==='x'?'调整串口设置与接收区宽度':parent===left?'调整串口设置与手动发送高度':'调整接收显示与转换工具高度');h.title='拖动调整；方向键微调；双击恢复默认比例';parent.append(h);
  let value=null;
  const size=()=>axis==='x'?parent.clientWidth:parent.clientHeight;
  const limits=()=>[minimum,Math.max(minimum,size()-10-otherMinimum)];
  function apply(next){if(!expanded||!h.getBoundingClientRect().width)return;const [lo,hi]=limits();value=Math.round(Math.max(lo,Math.min(hi,next)));parent.style.setProperty(key,value+'px');h.setAttribute('aria-valuemin',lo);h.setAttribute('aria-valuemax',hi);h.setAttribute('aria-valuenow',value);h.setAttribute('aria-valuetext',value+' 像素');}
  const defaultValue=()=>axis==='x'?initial:size()*initial;
  function stop(){if(active?.h!==h)return;const id=active.pointerId;active=null;h.classList.remove('dragging');if(h.hasPointerCapture(id))h.releasePointerCapture(id);}
  h.onpointerdown=e=>{if(e.button!==0||!expanded)return;apply(value??defaultValue());const box=parent.getBoundingClientRect();active={h,pointerId:e.pointerId,start:axis==='x'?e.clientX:e.clientY,value,scale:axis==='x'?box.width/parent.offsetWidth:box.height/parent.offsetHeight};h.setPointerCapture(e.pointerId);h.classList.add('dragging');e.preventDefault();};
  h.onpointermove=e=>{if(active?.h!==h||active.pointerId!==e.pointerId)return;apply(active.value+((axis==='x'?e.clientX:e.clientY)-active.start)/(active.scale||1));};
  h.onpointerup=stop;h.onpointercancel=stop;h.onlostpointercapture=()=>{if(active?.h===h){active=null;h.classList.remove('dragging');}};
  h.ondblclick=()=>apply(defaultValue());h.onkeydown=e=>{let next;const v=value??defaultValue(),delta=e.shiftKey?24:8;if(e.key===(axis==='x'?'ArrowLeft':'ArrowUp'))next=v-delta;else if(e.key===(axis==='x'?'ArrowRight':'ArrowDown'))next=v+delta;else if(e.key==='Home')next=limits()[0];else if(e.key==='End')next=limits()[1];else return;e.preventDefault();apply(next);};
  new ResizeObserver(()=>apply(value??defaultValue())).observe(parent);
  controls.push({refresh:()=>apply(value??defaultValue()),stop,reset:()=>{value=null;parent.style.removeProperty(key);requestAnimationFrame(()=>apply(defaultValue()));}});return h;
 }
 const across=install('uart-workspace-x-split',body,connection,'x','--uart-workspace-left',330,280,430);
 install('uart-workspace-left-y-split',left,connection,'y','--uart-workspace-connection',.50,240,190);
 install('uart-workspace-right-y-split',right,receive,'y','--uart-workspace-receive',.60,190,180);
 function sync(){const on=panel.classList.contains('expanded');if(on===expanded)return;expanded=on;
  if(on){oldOpen=convert.open;left.prepend(connection);left.append(send);right.prepend(receive);right.append(assist);assist.append(convert);convert.open=true;requestAnimationFrame(()=>controls.forEach(c=>c.refresh()));}
  else{controls.forEach(c=>c.stop());for(const {node,marker}of nodes)marker.parentNode.insertBefore(node,marker.nextSibling);convert.open=oldOpen;}
  dispatchEvent(new CustomEvent('electest:uart-layout',{detail:{expanded}}));
 }
 new MutationObserver(sync).observe(panel,{attributes:true,attributeFilter:['class']});
 const reset=actions.reset;actions.reset=function(){const result=reset.apply(this,arguments);controls.forEach(c=>c.reset());return result;};sync();
})();
