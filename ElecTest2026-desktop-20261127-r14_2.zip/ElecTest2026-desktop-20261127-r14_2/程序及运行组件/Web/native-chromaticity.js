'use strict';
// HTML-only adapter. A connection is not a measurement; never seed a measured point.
(() => {
 const panel=document.getElementById('ca'),body=panel.querySelector('.body');
 const card=document.createElement('section');card.className='cie-card';card.setAttribute('aria-label','CIE 1931 xy 色度图');
 card.innerHTML='<header class="cie-card-header"><div><h3>CIE 1931 xy</h3><p>2° 标准观察者 · 色度图</p></div><span id="cie-state" class="cie-state">等待测量</span></header><div class="cie-reading"><span>x <b id="cie-x">—</b></span><span>y <b id="cie-y">—</b></span><small>当前测量点</small></div><svg id="cie-plot" viewBox="0 0 640 650" role="img" aria-label="CIE1931色度图，尚无测量点"></svg><p id="cie-message" class="cie-message" role="status">连接仪器后点击测量，显示本次色度坐标。</p><p class="cie-note">背景颜色为 sRGB 近似示意；以坐标读数为准。色度不代表亮度，Lv 在左侧单独显示。</p>';
 body.append(card);const plot=card.querySelector('svg'),ns='http://www.w3.org/2000/svg';
 const X=x=>64+x*630,Y=y=>610-y*630;
 function el(tag,attrs={},text){const e=document.createElementNS(ns,tag);for(const[k,v]of Object.entries(attrs))e.setAttribute(k,v);if(text!==undefined)e.textContent=text;return e;}
 plot.append(el('rect',{x:X(0),y:Y(.9),width:504,height:567,fill:'var(--theme-chrome)',rx:2}));
 plot.append(el('image',{href:'cie1931-background.png',x:X(0),y:Y(.9),width:504,height:567,preserveAspectRatio:'none',opacity:.9}));
 for(let i=0;i<=8;i++){const x=i/10;plot.append(el('line',{x1:X(x),y1:Y(0),x2:X(x),y2:Y(.9),class:'cie-grid'}),el('text',{x:X(x),y:631,'text-anchor':'middle',class:'cie-axis'},x.toFixed(1)));}
 for(let i=0;i<=9;i++){const y=i/10;plot.append(el('line',{x1:X(0),y1:Y(y),x2:X(.8),y2:Y(y),class:'cie-grid'}),el('text',{x:53,y:Y(y)+4,'text-anchor':'end',class:'cie-axis'},y.toFixed(1)));}
 plot.append(el('path',{d:ElecCie1931Data.locus.map(([,x,y],i)=>(i?'L':'M')+X(x).toFixed(3)+' '+Y(y).toFixed(3)).join(' ')+'Z',class:'cie-locus'}));
 for(const nm of [460,480,500,520,540,560,580,600,650]){const row=ElecCie1931Data.locus.find(p=>p[0]===nm),x=X(row[1]),y=Y(row[2]);plot.append(el('circle',{cx:x,cy:y,r:2.2,class:'cie-wavelength-dot'}),el('text',{x:x+(nm<=520?-9:10),y:y+(nm===520?-11:4),'text-anchor':nm<=520?'end':'start',class:'cie-wavelength'},String(nm)));}
 plot.append(el('text',{x:589,y:614,class:'cie-axis-label'},'x'),el('text',{x:59,y:25,class:'cie-axis-label'},'y'));
 const mark=el('g',{id:'cie-marker',display:'none'}),guideX=el('line',{class:'cie-guide'}),guideY=el('line',{class:'cie-guide'}),halo=el('circle',{r:9,class:'cie-marker-halo'}),dot=el('circle',{r:4.5,class:'cie-marker-dot'});mark.append(guideX,guideY,halo,dot);plot.append(mark);
 let last=null;
 function clear(message='连接仪器后点击测量，显示本次色度坐标。'){
  last=null;mark.setAttribute('display','none');document.getElementById('cie-x').textContent='—';document.getElementById('cie-y').textContent='—';document.getElementById('cie-state').textContent='等待测量';document.getElementById('cie-message').textContent=message;plot.setAttribute('aria-label','CIE1931色度图，尚无有效测量点');dispatchEvent(new CustomEvent('electest:chromaticity-clear'));
 }
 function setReading(reading){
  const x=reading?.x,y=reading?.y;
  if(typeof x!=='number'||typeof y!=='number'||!Number.isFinite(x)||!Number.isFinite(y)||x<0||y<=0||x+y>1||x>.8||y>.9){clear('色度坐标无效或超出当前坐标范围，未绘制测量点。');return false;}
  last={x,y};document.getElementById('cie-x').textContent=x.toFixed(4);document.getElementById('cie-y').textContent=y.toFixed(4);document.getElementById('cie-state').textContent='当前测量点';document.getElementById('cie-message').textContent='本次仪器测量：x = '+x.toFixed(4)+'，y = '+y.toFixed(4)+'。';
  const px=X(x),py=Y(y);guideX.setAttribute('x1',px);guideX.setAttribute('x2',px);guideX.setAttribute('y1',Y(0));guideX.setAttribute('y2',py);guideY.setAttribute('x1',X(0));guideY.setAttribute('x2',px);guideY.setAttribute('y1',py);guideY.setAttribute('y2',py);
  for(const circle of [halo,dot]){circle.setAttribute('cx',px);circle.setAttribute('cy',py);}mark.setAttribute('display','inline');plot.setAttribute('aria-label','当前测量色度 x '+x.toFixed(4)+'，y '+y.toFixed(4));dispatchEvent(new CustomEvent('electest:chromaticity-reading',{detail:{x,y,lv:reading.lv??null,source:reading.source??null}}));return true;
 }
 window.ElecChromaticity={setReading,clear,snapshot:()=>last?{...last}:null,toPlot:(x,y)=>({x:X(x),y:Y(y)})};
 let revision=0;addEventListener('native-state',()=>{if(!state?.meterConnected){clear('仪器未连接');return;}if(!state.readings?.sx||!state.readings?.sy){clear('等待有效测量');return;}if(state.meterRevision&&state.meterRevision!==revision){revision=state.meterRevision;const source=document.getElementById('cie-demo-source')?.value||'unknown';setReading({x:Number(state.readings.sx),y:Number(state.readings.sy),lv:Number(state.readings.lv),source});}});clear();
})();
