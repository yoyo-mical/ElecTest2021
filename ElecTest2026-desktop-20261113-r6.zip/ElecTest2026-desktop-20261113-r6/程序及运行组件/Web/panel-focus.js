'use strict';
// Only rearrange existing controls: original handlers, IDs and values are retained.
(() => {
 const panels=[...document.querySelectorAll('.panel')],workspace=document.getElementById('workspace');
 const captions={uart:'连接设置 · 接收查看 · 手动发送',ca:'测量模式 · 当前读数 · 参数明细',code:'脚本 · 指令表 · 参数',chart:'曲线 · 当前数据 · 多组结果',recipe:'配方编辑 · 运行控制',patterns:'输出设置 · 图案库'};
 function section(cls){const el=document.createElement('div');el.className=cls+' focus-group';return el;}
 const uart=document.querySelector('#uart>.body'),connection=section('serial-connection');uart.prepend(connection);connection.append(uart.querySelector('.field-grid').parentElement,uart.querySelector('.serial-buttons'));
 const ca=document.querySelector('#ca>.body'),main=section('meter-main'),details=section('meter-details');ca.append(main,details);main.append(ca.querySelector('.ca-mode'),ca.querySelector('.measure'));details.append(ca.querySelector('.metric-grid'),ca.querySelector('.ca-buttons'));
 const pattern=document.querySelector('#patterns>.body'),settings=section('pattern-settings-focus'),library=section('pattern-library-focus');
 const output=pattern.firstElementChild,categories=pattern.querySelector('.pattern-categories'),libraryHeading=categories.previousElementSibling;
 pattern.append(settings,library);settings.append(output,pattern.querySelector('.pattern-color-groups'),pattern.querySelector('.pattern-bottom'));library.append(libraryHeading,categories,document.getElementById('pattern-grid'),document.getElementById('pattern-disclosure'));
 for(const panel of panels){
  const header=panel.querySelector('.panel-header'),actions=header.querySelector('.panel-actions'),caption=document.createElement('span');caption.className='expanded-caption';caption.textContent=captions[panel.id];header.insertBefore(caption,actions);
  const button=panel.querySelector('[data-expand]'),label=document.createElement('span');label.className='expanded-restore-label';label.textContent='还原';button.append(label);
 }
 function sync(){
  const active=panels.find(p=>p.classList.contains('expanded'));
  for(const panel of panels){const expanded=panel===active,button=panel.querySelector('[data-expand]'),name=panel.querySelector('h2').textContent;panel.inert=!!active&&!expanded;button.setAttribute('aria-expanded',String(expanded));button.setAttribute('aria-label',(expanded?'还原':'展开')+name);button.title=expanded?'还原面板（Esc）':'展开面板';}
  for(const el of document.querySelectorAll('[data-split],.internal-split'))el.inert=!!active;
  workspace.classList.toggle('has-focused-panel',!!active);
 }
 for(const panel of panels)new MutationObserver(sync).observe(panel,{attributes:true,attributeFilter:['class']});
 sync();
})();
