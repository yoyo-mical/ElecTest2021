'use strict';
// Read-only view of bounded native RX metadata. This module never queries or writes a device.
(() => {
 const app=document.getElementById('app'),bar=app.querySelector('.topbar'),right=bar.querySelector('.top-right'),meta=bar.querySelector('.project');
 meta.replaceChildren();meta.classList.add('boot-device-meta');meta.hidden=true;
 const trigger=document.createElement('button');trigger.id='device-info';trigger.type='button';trigger.dataset.icon='info';trigger.textContent='设备信息';trigger.setAttribute('aria-haspopup','dialog');trigger.setAttribute('aria-expanded','false');right.prepend(trigger);icons();
 let signature='',headerSignature='',info=null,overlay=null,returnFocus=null,background=[],layoutQueued=false;
 const present=(f,k)=>Object.hasOwn(f,k)&&f[k]!==null&&String(f[k]).trim()!=='';
 const text=(f,k)=>present(f,k)?String(f[k]):'未读取';
 const number=(f,k)=>present(f,k)&&Number.isFinite(Number(f[k]))?Number(f[k]):null;
 function node(tag,cls,value){const e=document.createElement(tag);if(cls)e.className=cls;if(value!==undefined)e.textContent=String(value);return e;}
 function field(label,value,missing=false){const e=node('div','device-info-field');e.append(node('span','',label),node('b',missing?'missing':'device-info-mono',value));return e;}
 function sum(f,keys){const values=keys.map(k=>number(f,k));return values.every(v=>v!==null&&v>=0)?values.reduce((a,b)=>a+b,0):null;}
 function timing(f){const h=sum(f,['hact','hsw','hfp','hbp']),v=sum(f,['vact','vsw','vfp','vbp']),clock=number(f,'pclk');return {h,v,rate:clock!==null&&clock>0&&h>0&&v>0?clock/h/v:null};}
 function layout(){layoutQueued=false;bar.classList.remove('boot-meta-wrapped');if(meta.hidden)return;
  const style=getComputedStyle(bar),padding=parseFloat(style.paddingLeft)+parseFloat(style.paddingRight),gap=parseFloat(style.columnGap)||0;
  const occupied=[...bar.children].filter(e=>e!==meta&&getComputedStyle(e).display!=='none').reduce((n,e)=>n+e.getBoundingClientRect().width,0);
  const required=[...meta.children].reduce((n,e)=>{const label=e.querySelector('.boot-device-label'),value=e.querySelector('.boot-device-value');return n+label.getBoundingClientRect().width+value.scrollWidth+5+(parseFloat(getComputedStyle(e).paddingLeft)||0);},0)+Math.max(0,meta.children.length-1)*12;
  if(required>bar.clientWidth-padding-occupied-gap*bar.children.length)bar.classList.add('boot-meta-wrapped');
 }
 function queueLayout(){if(layoutQueued)return;layoutQueued=true;requestAnimationFrame(layout);}
 new ResizeObserver(queueLayout).observe(right);addEventListener('resize',queueLayout);addEventListener('electest:font-scale',queueLayout);
 function close(){if(!overlay)return;overlay.remove();overlay=null;for(const [e,old]of background)e.inert=old;background=[];trigger.setAttribute('aria-expanded','false');(returnFocus?.isConnected?returnFocus:trigger).focus();}
 function renderDialog(){
  if(!overlay)return;const dialog=overlay.firstElementChild,content=dialog.querySelector('.device-info-content'),footer=dialog.querySelector('.device-info-footer'),badge=dialog.querySelector('.device-info-state');
  const f=info?.connected?info.fields||{}:{},has=!!info?.connected&&!!info.captured&&Object.keys(f).length>0;
  const scroll=content.scrollTop;dialog.classList.toggle('is-empty',!has);content.replaceChildren();footer.querySelector('button').textContent=has?'关闭':'知道了';
  badge.hidden=!has||(!info.incomplete&&info.bootStartSeen);badge.textContent=info?.incomplete?'信息不完整':'部分信息';
  if(!has){content.append(node('h3','device-info-empty-title','未读到设备信息'),node('p','device-info-empty-message','建议重启屏幕后再次读取。'));return;}
  const basic=node('section','device-info-section');basic.append(node('h3','','设备基础信息'));const grid=node('div','device-info-basic');
  for(const [label,key]of [['产品型号','project'],['IC 型号','ic'],['固件版本 · FW','fw'],['GPU 版本','gpuVersion'],['测试模式','testMode'],['运行模式','runMode']])grid.append(field(label,text(f,key),!present(f,key)));
  const hz=number(f,'mcuHz');grid.append(field('MCU 主频',hz===null?'未读取':(hz/1e6).toLocaleString('en-US',{maximumFractionDigits:6,useGrouping:false})+' MHz',hz===null),field('背光 PWM · 原始值',text(f,'pwmRaw'),!present(f,'pwmRaw')));basic.append(grid);content.append(basic);
  const video=node('section','device-info-section');video.append(node('h3','','视频时序'));
  const timingKeys=['pclk','hact','vact','hsw','vsw','hfp','vfp','hbp','vbp','refreshReported'];
  if(!timingKeys.some(k=>present(f,k)))video.append(node('div','device-info-no-timing','未读取到视频时序信息'));
  else{
   const derived=timing(f),cards=node('div','device-info-timing-cards');
   const card=(label,value,unit='')=>{const e=node('div','device-info-small');e.append(node('span','',label));const strong=node('strong',value==='未读取'?'missing':'',value);if(unit&&value!=='未读取')strong.append(node('small','',' '+unit));e.append(strong);cards.append(e);};
   card('有效分辨率',present(f,'hact')&&present(f,'vact')?f.hact+' × '+f.vact:'未读取');
   card('像素时钟 · PCLK',number(f,'pclk')===null?'未读取':(Number(f.pclk)/1e6).toLocaleString('en-US',{maximumFractionDigits:6,useGrouping:false}),'MHz');
   card('刷新率 · 设备报告',text(f,'refreshReported'),'Hz');card('刷新率 · 时序计算',derived.rate===null?'未读取':'≈ '+Number(derived.rate.toFixed(2)),'Hz');video.append(cards);
   const table=node('table','device-info-timing');table.setAttribute('aria-label','视频时序，水平单位为像素时钟周期，垂直单位为行');const head=table.createTHead().insertRow();
   for(const label of ['方向','有效像素 · ACT','同步宽度 · SW','前肩 · FP','后肩 · BP','总计 · TOTAL'])head.append(node('th','',label));
   const body=table.createTBody();for(const [axis,kind,total]of [['水平 · H','h',derived.h],['垂直 · V','v',derived.v]]){const row=body.insertRow();row.append(node('td','',axis));for(const name of ['act','sw','fp','bp']){const cell=node('td','',text(f,kind+name));cell.title=kind==='h'?'像素时钟周期':'行';row.append(cell);}row.append(node('td','',total===null?'未读取':total));}video.append(table);
  }
  content.append(video);
  const reading=node('section','device-info-section');reading.append(node('h3','','当前回读'));const values=node('div','device-info-readback');
  for(const [label,key,unit]of [['VCOM 码值','vcom',''],['VCOM 电压','vcomVoltage','V'],['VCOM 调整次数','vcomTrimTimes','次'],['OTP 次数','otpTimes','次']]){
   const card=node('div','device-info-reading');card.append(node('span','',label));const strong=node('strong',present(f,key)?'':'missing',text(f,key));if(unit&&present(f,key))strong.append(node('small','',' '+unit));card.append(strong);values.append(card);
  }
  reading.append(values);content.append(reading);content.scrollTop=scroll;
 }
 function open(){if(overlay)return;returnFocus=document.activeElement;overlay=node('div','device-info-backdrop');const dialog=node('section','device-info-dialog');dialog.setAttribute('role','dialog');dialog.setAttribute('aria-modal','true');dialog.setAttribute('aria-labelledby','device-info-title');
  const head=node('header','device-info-head'),title=node('h2','','设备信息');title.id='device-info-title';const badge=node('span','device-info-state'),dismiss=node('button','device-info-close','×');dismiss.type='button';dismiss.setAttribute('aria-label','关闭设备信息');dismiss.onclick=close;head.append(title,badge,dismiss);
  const content=node('div','device-info-content'),footer=node('footer','device-info-footer'),done=node('button','','关闭');done.type='button';done.onclick=close;footer.append(done);dialog.append(head,content,footer);overlay.append(dialog);app.append(overlay);
  background=[...app.children].filter(e=>e!==overlay).map(e=>[e,e.inert]);for(const [e]of background)e.inert=true;
  overlay.addEventListener('pointerdown',e=>{if(e.target===overlay)close();});trigger.setAttribute('aria-expanded','true');renderDialog();dismiss.focus();
 }
 trigger.onclick=open;
 document.addEventListener('keydown',e=>{if(!overlay)return;if(e.key==='Escape'){e.preventDefault();e.stopImmediatePropagation();close();}else if(e.key==='Tab'){const buttons=[...overlay.querySelectorAll('button:not([disabled])')];const first=buttons[0],last=buttons.at(-1);if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}}},true);
 function sync(){const next=state?.authorized?state?.bootInfo||null:null;info=next;
  const f=info?.connected?info.fields||{}:{},key=JSON.stringify([info?.session,!!info?.connected,!!info?.captured,!!info?.bootStartSeen,!!info?.incomplete,Object.keys(f).sort().map(k=>[k,f[k]])]);
  if(key===signature)return;signature=key;
  const headerKey=JSON.stringify(['project','ic','fw'].map(k=>present(f,k)?f[k]:null));
  if(headerKey!==headerSignature){headerSignature=headerKey;meta.replaceChildren();
   for(const [key,label]of [['project','Project'],['ic','IC'],['fw','FW']]){if(!present(f,key))continue;const field=node('span','boot-device-field');const value=node('span','boot-device-value',f[key]);value.title=f[key];field.append(node('span','boot-device-label',label),value);meta.append(field);}
   meta.hidden=!meta.children.length;queueLayout();
  }
  renderDialog();
 }
 addEventListener('native-state',sync);sync();
})();
